// Crée .env.local avec une clé secrète aléatoire et le mot de passe fourni.
// Usage : node scripts/setup-env.mjs "MonMotDePasse"
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';

const target = '.env.local';
if (existsSync(target)) {
  console.log('.env.local existe déjà : aucune modification.');
  process.exit(0);
}

const password = (process.argv[2] || '').trim();
if (password.length < 8) {
  console.error('Mot de passe trop court (8 caractères minimum).');
  process.exit(1);
}

let content = readFileSync('.env.example', 'utf8');
content = content
  .replace(/^ADMIN_PASSWORD=.*$/m, `ADMIN_PASSWORD=${password}`)
  .replace(/^ADMIN_SECRET=.*$/m, `ADMIN_SECRET=${randomBytes(48).toString('hex')}`);
writeFileSync(target, content, { encoding: 'utf8', mode: 0o600 });
console.log('.env.local créé avec succès.');
