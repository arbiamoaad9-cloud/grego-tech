// Import du catalogue depuis data/grego_products_import.json (export Shopify)
// -> data/products.json, en ne conservant que les serrures digitales.
// Usage : npm run import:products   (les produits déjà présents sont conservés)
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import sanitizeHtml from 'sanitize-html';

const SRC = 'data/grego_products_import.json';
const OUT = 'data/products.json';

const INCLUDE = /(serrure|poign[ée]e\s+digital|face\s*id\s+luxury|pack\s+villa)/i;
const EXCLUDE = /(porte\s+sbk|coffre|tourniquet|terminal|imprimante|barrier|lecteur|bracelet|proma|zk|speedface)/i;

const MODE_RX = {
  fingerprint: /empreinte/i,
  face: /facial|face ?id|visage/i,
  palm: /paume|palm|veine/i,
  code: /code|mot de passe|\bpin\b/i,
  card: /carte|badge|nfc|rfid/i,
  app: /application|tuya|wi-?fi|bluetooth|smartphone/i,
  key: /cl[ée]/i,
};

const slugify = (s) =>
  s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

const clean = (html) =>
  sanitizeHtml(html || '', {
    allowedTags: ['p', 'h2', 'h3', 'ul', 'ol', 'li', 'strong', 'em', 'br'],
    allowedAttributes: {},
    transformTags: { b: 'strong', i: 'em', h1: 'h2', h4: 'h3' },
  })
    .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, '')
    .replace(/\s+/g, ' ')
    .trim();

const plain = (html) => (html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');

const source = JSON.parse(readFileSync(SRC, 'utf8'));
const existing = existsSync(OUT) ? JSON.parse(readFileSync(OUT, 'utf8')) : [];
const known = new Set(existing.map((p) => p.id));
const now = new Date().toISOString();

const added = source
  .filter((p) => INCLUDE.test(p.title) && !EXCLUDE.test(p.title) && !known.has(String(p.id)))
  .map((p) => {
    const text = `${p.title} ${plain(p.description)}`;
    const modes = Object.keys(MODE_RX).filter((m) => MODE_RX[m].test(text));
    if (!modes.includes('key')) modes.push('key');
    const price = Number(p.price) || 0;
    const compare = Number(p.compare_at_price) || null;
    return {
      id: String(p.id),
      slug: slugify(p.title),
      sku: p.handle || '',
      name: { fr: p.title, ar: p.title },
      shortDescription: { fr: '', ar: '' },
      description: { fr: clean(p.description), ar: '' },
      price,
      compareAtPrice: compare && compare > price ? compare : null,
      images: (p.images || []).filter((u) => /^https:\/\/(cdn\.shopify\.com|(www\.)?sbk-quincaillerie\.com)\//.test(u)),
      modes,
      collections: [],
      features: { fr: [], ar: [] },
      variants: [],
      stock: 10,
      visible: false, // à vérifier et compléter (traduction AR) dans /admin avant publication
      featured: false,
      createdAt: now,
      updatedAt: now,
    };
  });

writeFileSync(OUT, JSON.stringify([...existing, ...added], null, 2));
console.log(`${added.length} nouvelle(s) serrure(s) importée(s) (masquées, à valider dans /admin).`);
