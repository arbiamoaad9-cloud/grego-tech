# Grego Tech — Boutique de serrures digitales

Site e-commerce de **Grego SARL** (Maroc) dédié aux serrures digitales, poignées biométriques et serrures connectées.
Conception et développement : **Dar Digital**.

## Démarrage rapide (Windows)

1. Installer **Node.js 18 ou plus** (version LTS) : https://nodejs.org
2. Décompresser le dossier, puis double-cliquer sur **`LANCER-GREGO.bat`**.
3. Au premier lancement, choisir le mot de passe administrateur.
4. Le site s'ouvre sur http://localhost:3000 — administration : http://localhost:3000/admin

macOS / Linux : `./lancer-grego.sh`

## Fonctionnalités

| Module | Détail |
| --- | --- |
| Bilingue FR / AR | Routes `/fr` et `/ar`, dictionnaires `locales/fr.json` et `locales/ar.json`, RTL natif (`dir="rtl"`, police Tajawal), sélecteur de langue mémorisé |
| Accueil | Hero animé (serrure interactive, 4 points d'exploration), garanties, collections, best-sellers, anatomie 3D au défilement, comparatif, vérification de porte, FAQ |
| Catalogue | 18 serrures digitales, filtres par mode d'ouverture et collection, recherche, tri, aperçu rapide |
| Fiche produit | Galerie, variantes, quantité, panier, commande WhatsApp, données structurées Product |
| Commande | Panier → nom, téléphone marocain et adresse complète obligatoires → commande enregistrée (n° GT-AAAAMMJJ-XXXX, prix recalculés côté serveur) → confirmation WhatsApp |
| Vérifier ma porte | Photo + ville + type de porte, partage natif sur mobile ou WhatsApp sur ordinateur |
| Administration `/admin` | **Commandes** (liste, détail client, statut Nouvelle / Confirmée / Livrée / Annulée, chiffre d'affaires, contact WhatsApp) et **Produits** (ajout / modification / masquage / suppression, prix, remises, stock, photos importées depuis l'ordinateur — glisser-déposer, conversion WebP automatique — variantes, textes FR / AR) |

## Performance

- Pages générées statiquement (SSG) et régénérées automatiquement (ISR, 5 min) ou immédiatement après chaque modification dans l'admin.
- Images optimisées AVIF / WebP, tailles responsives, chargement différé.
- Animations lourdes (hero, anatomie 3D, aperçu rapide) chargées à la demande via `next/dynamic`.

## Sécurité

- En-têtes stricts : CSP, HSTS, X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy, COOP.
- Session admin signée HMAC-SHA256, cookie `HttpOnly` + `SameSite=Strict`, expiration 8 h.
- Limitation des tentatives de connexion (5 / 15 min), comparaison en temps constant.
- Protection CSRF : vérification de l'origine + en-tête dédié sur toutes les écritures.
- Validation stricte (zod) et assainissement HTML (liste blanche) des données produit.
- Paramètres d'URL et formulaires filtrés en liste blanche ; imports d'images vérifiés par signature binaire.

## Gestion du catalogue

- Données : `data/products.json` (sauvegarde automatique dans `data/products.backup.json` à chaque modification).
- Images importées : `data/uploads/` (servies par `/api/media/...`).
- Commandes : `data/orders.json`.
- Nouvel export Shopify : remplacer `data/grego_products_import.json` puis `npm run import:products`
  (seules les serrures digitales sont importées, masquées jusqu'à validation dans l'admin).

## Configuration (`.env.local`)

| Variable | Rôle |
| --- | --- |
| `ADMIN_PASSWORD` | Mot de passe de l'administration |
| `ADMIN_SECRET` | Clé de signature des sessions (générée automatiquement) |
| `NEXT_PUBLIC_SITE_URL` | URL publique (SEO, sitemap) |
| `NEXT_PUBLIC_WHATSAPP` | Numéro WhatsApp (défaut : 212648701885) |
| `NEXT_PUBLIC_CONTACT_EMAIL` | E-mail affiché (optionnel) |

## Mise en ligne

**Démonstration gratuite — Render** (fichier `render.yaml` inclus) :
1. Publier le dossier sur GitHub (dépôt privé, via GitHub Desktop).
2. render.com → *Sign in with GitHub* → **New + → Blueprint** → choisir le dépôt.
3. Saisir `ADMIN_PASSWORD`, valider : le site est en ligne en 5 à 8 minutes.

Offre gratuite : mise en veille après 15 min d'inactivité et données en ligne (commandes, produits modifiés, photos)
réinitialisées à chaque redémarrage — réservé à la démonstration.

**Production** : Render Starter + disque persistant monté sur `/var/data` avec `DATA_DIR=/var/data`,
ou un VPS Node.js (`npm install && npm run build && pm2 start npm --name grego -- start`) derrière HTTPS.

## Scripts

| Commande | Rôle |
| --- | --- |
| `npm run dev` | Développement |
| `npm run build` / `npm run start` | Production |
| `npm run typecheck` | Vérification TypeScript |
| `npm run import:products` | Import d'un export Shopify |

---

© Grego SARL — Créé avec excellence par Dar Digital.
