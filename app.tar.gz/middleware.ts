import { NextResponse, type NextRequest } from 'next/server';
import { SESSION_COOKIE, verifySessionToken } from '@/lib/auth';
import { DEFAULT_LOCALE, LOCALE_COOKIE, LOCALES, isLocale } from '@/lib/types';

function preferredLocale(req: NextRequest): string {
  const fromCookie = req.cookies.get(LOCALE_COOKIE)?.value;
  if (isLocale(fromCookie)) return fromCookie;
  const accept = req.headers.get('accept-language') || '';
  return /^ar\b|,\s*ar\b/i.test(accept) ? 'ar' : DEFAULT_LOCALE;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // --- Espace d'administration -------------------------------------------
  if (pathname.startsWith('/admin') || pathname.startsWith('/api/admin')) {
    const isLogin = pathname === '/admin/login' || pathname === '/api/admin/login';
    if (isLogin) return NextResponse.next();

    const ok = await verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value);
    if (ok) return NextResponse.next();

    if (pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const url = req.nextUrl.clone();
    url.pathname = '/admin/login';
    url.search = '';
    return NextResponse.redirect(url);
  }

  if (pathname.startsWith('/api/')) return NextResponse.next();

  // --- Langue -------------------------------------------------------------
  const first = pathname.split('/')[1];
  if ((LOCALES as readonly string[]).includes(first)) return NextResponse.next();

  const url = req.nextUrl.clone();
  url.pathname = `/${preferredLocale(req)}${pathname === '/' ? '' : pathname}`;
  return NextResponse.redirect(url);
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|brand/|favicon.ico|icon.svg|robots.txt|sitemap.xml|.*\\.(?:png|jpg|jpeg|webp|avif|svg|ico|txt|xml)$).*)'],
};
