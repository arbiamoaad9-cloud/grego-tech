import { revalidatePath } from 'next/cache';

/** Régénère toutes les pages publiques (accueil, catalogue, fiches) après une modification. */
export function refreshStorefront() {
  revalidatePath('/[lang]', 'layout');
  revalidatePath('/sitemap.xml');
}
