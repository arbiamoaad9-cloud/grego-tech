export const SITE = {
  name: 'Grego Tech',
  legalName: 'Grego SARL',
  url: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
  whatsapp: (process.env.NEXT_PUBLIC_WHATSAPP || '212648701885').replace(/\D/g, ''),
  phoneDisplay: '+212 648 70 18 85',
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || '',
  agency: { name: 'Dar Digital', icon: '/brand/dar-digital-icon.png' },
} as const;

export function whatsappUrl(message?: string): string {
  const base = `https://wa.me/${SITE.whatsapp}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}
