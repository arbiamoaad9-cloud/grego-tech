import { promises as fs } from 'fs';
import path from 'path';
import type { Product } from './types';
import { BUNDLED_DATA_DIR, DATA_DIR } from './data-dir';

const FILE = path.join(DATA_DIR, 'products.json');

async function ensureSeed() {
  try {
    await fs.access(FILE);
  } catch {
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.copyFile(path.join(BUNDLED_DATA_DIR, 'products.json'), FILE);
  }
}

let cache: { mtimeMs: number; products: Product[] } | null = null;
let writeQueue: Promise<unknown> = Promise.resolve();

export async function readProducts(): Promise<Product[]> {
  if (DATA_DIR !== BUNDLED_DATA_DIR) await ensureSeed();
  const stat = await fs.stat(FILE);
  if (cache && cache.mtimeMs === stat.mtimeMs) return cache.products;
  const raw = await fs.readFile(FILE, 'utf8');
  const products = JSON.parse(raw) as Product[];
  cache = { mtimeMs: stat.mtimeMs, products };
  return products;
}

export async function getVisibleProducts(): Promise<Product[]> {
  return (await readProducts()).filter((p) => p.visible);
}

export async function getProductBySlug(slug: string): Promise<Product | undefined> {
  return (await readProducts()).find((p) => p.slug === slug);
}

/**
 * Écriture atomique (fichier temporaire + renommage) et sérialisée
 * pour éviter toute corruption lors de modifications simultanées.
 */
export function mutateProducts<T>(fn: (products: Product[]) => { next: Product[]; result: T }): Promise<T> {
  const run = async () => {
    const current = await readProducts();
    const { next, result } = fn(structuredClone(current));
    const tmp = `${FILE}.${process.pid}.${Date.now()}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(next, null, 2), 'utf8');
    await fs.copyFile(FILE, path.join(DATA_DIR, 'products.backup.json')).catch(() => undefined);
    await fs.rename(tmp, FILE);
    cache = null;
    return result;
  };
  const p = writeQueue.then(run, run);
  writeQueue = p.catch(() => undefined);
  return p;
}
