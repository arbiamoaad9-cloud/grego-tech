/**
 * Session administrateur signée (HMAC-SHA256) — compatible Edge (middleware) et Node.
 * Format du jeton : <expiration_ms>.<signature_hex>
 */
export const SESSION_COOKIE = 'grego_admin';
export const SESSION_TTL_MS = 1000 * 60 * 60 * 8; // 8 heures

const encoder = new TextEncoder();

function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

async function hmac(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  return toHex(await crypto.subtle.sign('HMAC', key, encoder.encode(data)));
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export function getAuthSecret(): string | null {
  const s = process.env.ADMIN_SECRET;
  return s && s.length >= 32 ? s : null;
}

export async function createSessionToken(): Promise<string> {
  const secret = getAuthSecret();
  if (!secret) throw new Error('ADMIN_SECRET manquant ou trop court');
  const exp = Date.now() + SESSION_TTL_MS;
  return `${exp}.${await hmac(secret, `admin:${exp}`)}`;
}

export async function verifySessionToken(token: string | undefined | null): Promise<boolean> {
  const secret = getAuthSecret();
  if (!secret || !token) return false;
  const [expStr, sig] = token.split('.');
  const exp = Number(expStr);
  if (!exp || !sig || exp < Date.now()) return false;
  return safeEqual(sig, await hmac(secret, `admin:${exp}`));
}

/** Comparaison du mot de passe en temps constant (via empreintes HMAC). */
export async function checkPassword(candidate: string): Promise<boolean> {
  const expected = process.env.ADMIN_PASSWORD;
  const secret = getAuthSecret();
  if (!expected || !secret || typeof candidate !== 'string') return false;
  const [a, b] = await Promise.all([hmac(secret, `pw:${candidate}`), hmac(secret, `pw:${expected}`)]);
  return safeEqual(a, b);
}

/** Vérifie que la requête provient bien du site (protection CSRF). */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get('origin');
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host');
  if (!origin || !host) return false;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}
