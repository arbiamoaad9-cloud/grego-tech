import path from 'path';

/**
 * Dossier des données modifiables (produits, commandes, photos).
 * Par défaut : ./data. En production, DATA_DIR peut pointer vers un disque persistant
 * (ex. /var/data) : le catalogue d'origine y est copié automatiquement au premier lancement.
 */
export const BUNDLED_DATA_DIR = path.join(process.cwd(), 'data');
export const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : BUNDLED_DATA_DIR;
