import { promises as fs } from 'fs';
import path from 'path';
import type { Order } from './types';
import { DATA_DIR } from './data-dir';

const FILE = path.join(DATA_DIR, 'orders.json');
let queue: Promise<unknown> = Promise.resolve();

export async function readOrders(): Promise<Order[]> {
  try {
    return JSON.parse(await fs.readFile(FILE, 'utf8')) as Order[];
  } catch {
    return [];
  }
}

/** Écriture atomique et sérialisée du fichier des commandes. */
export function mutateOrders<T>(fn: (orders: Order[]) => { next: Order[]; result: T }): Promise<T> {
  const run = async () => {
    const { next, result } = fn(await readOrders());
    await fs.mkdir(DATA_DIR, { recursive: true });
    const tmp = `${FILE}.${process.pid}.${Date.now()}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(next, null, 2), 'utf8');
    await fs.rename(tmp, FILE);
    return result;
  };
  const p = queue.then(run, run);
  queue = p.catch(() => undefined);
  return p;
}

export function newOrderId(existing: Order[]): string {
  const d = new Date();
  const day = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  let id = '';
  do {
    id = `GT-${day}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  } while (existing.some((o) => o.id === id));
  return id;
}
