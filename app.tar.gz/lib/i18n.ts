import fr from '@/locales/fr.json';
import ar from '@/locales/ar.json';
import { LOCALES, DEFAULT_LOCALE, LOCALE_COOKIE, type Locale } from './types';

export type Dictionary = typeof fr;

const dictionaries: Record<Locale, Dictionary> = { fr, ar: ar as Dictionary };


export function getDictionary(locale: Locale): Dictionary {
  return dictionaries[locale] ?? dictionaries.fr;
}

export function dir(locale: Locale): 'rtl' | 'ltr' {
  return locale === 'ar' ? 'rtl' : 'ltr';
}

/** Remplace les variables {cle} dans une chaîne traduite. */
export function t(template: string, vars: Record<string, string | number> = {}): string {
  return template.replace(/\{(\w+)\}/g, (_, k: string) => (k in vars ? String(vars[k]) : `{${k}}`));
}

export function localePath(locale: Locale, path = ''): string {
  const clean = path.startsWith('/') ? path : `/${path}`;
  return `/${locale}${clean === '/' ? '' : clean}`;
}

export { LOCALES, DEFAULT_LOCALE, LOCALE_COOKIE };
