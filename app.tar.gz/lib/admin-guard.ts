import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { SESSION_COOKIE, isSameOrigin, verifySessionToken } from './auth';

/**
 * Contrôle d'accès des routes API d'administration (en complément du middleware).
 * Retourne une réponse d'erreur, ou null si la requête est autorisée.
 */
export async function guardAdmin(req: Request): Promise<NextResponse | null> {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!(await verifySessionToken(token))) {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    if (!isSameOrigin(req) || req.headers.get('x-grego-request') !== '1') {
      return NextResponse.json({ error: 'Requête refusée' }, { status: 403 });
    }
  }
  return null;
}
