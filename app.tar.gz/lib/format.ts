import type { Locale } from './types';

export function formatPrice(value: number, locale: Locale): string {
  // Séparateur de milliers fixe (espace insécable) : rendu identique serveur / navigateur
  const n = String(Math.round(value)).replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
  return locale === 'ar' ? `${n} درهم` : `${n} DH`;
}

export function discountPercent(price: number, compareAt: number | null): number | null {
  if (!compareAt || compareAt <= price) return null;
  return Math.round(((compareAt - price) / compareAt) * 100);
}
