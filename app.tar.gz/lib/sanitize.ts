/**
 * Nettoyage des saisies utilisateur côté client et serveur (texte brut).
 * Supprime balises, caractères de contrôle et limite la longueur.
 */
export function cleanText(input: unknown, max = 300): string {
  if (typeof input !== 'string') return '';
  return input
    .normalize('NFKC')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/[<>]/g, '')
    .replace(/javascript:/gi, '')
    .replace(/\s{3,}/g, '  ')
    .trim()
    .slice(0, max);
}

export function cleanPhone(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input.replace(/[^\d+\s]/g, '').trim().slice(0, 20);
}

/** Ne conserve que les valeurs présentes dans la liste blanche. */
export function pickAllowed<T extends string>(values: string[], allowed: readonly T[]): T[] {
  const set = new Set<string>(allowed);
  return Array.from(new Set(values.filter((v) => set.has(v)))) as T[];
}

export function cleanSlug(input: unknown): string {
  if (typeof input !== 'string') return '';
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}
