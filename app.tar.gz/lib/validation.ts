import { z } from 'zod';
import sanitizeHtml from 'sanitize-html';
import { COLLECTIONS, UNLOCK_MODES, type Product } from './types';
import { cleanSlug, cleanText } from './sanitize';

const ALLOWED_IMAGE = /^(https:\/\/(cdn\.shopify\.com|(www\.)?sbk-quincaillerie\.com)\/|\/api\/media\/[a-z0-9-]+\.(jpg|png|webp|avif)$)/i;

export function sanitizeDescription(html: string): string {
  return sanitizeHtml(html, {
    allowedTags: ['p', 'h2', 'h3', 'ul', 'ol', 'li', 'strong', 'em', 'br'],
    allowedAttributes: {},
    transformTags: { b: 'strong', i: 'em', h1: 'h2', h4: 'h3' },
    disallowedTagsMode: 'discard',
  }).slice(0, 20000);
}

const text = (max: number) => z.string().max(max * 2).transform((v) => cleanText(v, max));
const localized = (max: number) => z.object({ fr: text(max), ar: text(max) });

export const productInputSchema = z.object({
  name: z.object({ fr: text(120).pipe(z.string().min(2)), ar: text(120) }),
  slug: z.string().max(100).optional(),
  sku: text(80).optional().default(''),
  shortDescription: localized(300),
  description: z.object({ fr: z.string().max(40000), ar: z.string().max(40000) }),
  price: z.coerce.number().min(0).max(1_000_000),
  compareAtPrice: z.coerce.number().min(0).max(1_000_000).nullable().optional(),
  images: z
    .array(z.string().trim().max(500))
    .max(12)
    .transform((arr) => arr.filter((u) => ALLOWED_IMAGE.test(u))),
  modes: z.array(z.enum(UNLOCK_MODES)).max(UNLOCK_MODES.length),
  collections: z.array(z.enum(COLLECTIONS)).max(COLLECTIONS.length),
  features: z.object({
    fr: z.array(text(120)).max(20),
    ar: z.array(text(120)).max(20),
  }),
  variants: z
    .array(
      z.object({
        id: z.string().max(40).optional(),
        label: localized(60),
        price: z.coerce.number().min(0).max(1_000_000).nullable().optional(),
      }),
    )
    .max(10),
  stock: z.coerce.number().int().min(0).max(100000),
  visible: z.boolean(),
  featured: z.boolean(),
});

export type ProductInput = z.infer<typeof productInputSchema>;

export function buildProduct(input: ProductInput, existing?: Product): Product {
  const now = new Date().toISOString();
  const compare = input.compareAtPrice && input.compareAtPrice > input.price ? input.compareAtPrice : null;
  return {
    id: existing?.id ?? `${Date.now()}${Math.floor(Math.random() * 1000)}`,
    slug: cleanSlug(input.slug || input.name.fr) || `serrure-${Date.now()}`,
    sku: input.sku ?? '',
    name: input.name,
    shortDescription: input.shortDescription,
    description: {
      fr: sanitizeDescription(input.description.fr),
      ar: sanitizeDescription(input.description.ar),
    },
    price: Math.round(input.price),
    compareAtPrice: compare ? Math.round(compare) : null,
    images: input.images,
    modes: input.modes,
    collections: input.collections,
    features: {
      fr: input.features.fr.filter(Boolean),
      ar: input.features.ar.filter(Boolean),
    },
    variants: input.variants.map((v, i) => ({
      id: cleanSlug(v.id || v.label.fr) || `v${i + 1}`,
      label: v.label,
      price: v.price ?? null,
    })),
    stock: input.stock,
    visible: input.visible,
    featured: input.featured,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
  };
}
