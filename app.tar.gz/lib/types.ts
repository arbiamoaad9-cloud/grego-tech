export const LOCALES = ['fr', 'ar'] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = 'fr';
export const LOCALE_COOKIE = 'grego_lang';

export type Localized<T = string> = Record<Locale, T>;

export const UNLOCK_MODES = ['fingerprint', 'face', 'palm', 'code', 'card', 'app', 'key'] as const;
export type UnlockMode = (typeof UNLOCK_MODES)[number];

/** Modes proposés dans les filtres du catalogue. */
export const FILTER_MODES: UnlockMode[] = ['fingerprint', 'face', 'code', 'app', 'card'];

export const COLLECTIONS = ['face-3d', 'handle', 'apartment', 'waterproof'] as const;
export type Collection = (typeof COLLECTIONS)[number];

export interface Variant {
  id: string;
  label: Localized;
  /** Prix spécifique à la variante (null = prix du produit). */
  price: number | null;
}

export interface Product {
  id: string;
  slug: string;
  sku: string;
  name: Localized;
  shortDescription: Localized;
  /** HTML nettoyé (liste blanche de balises). */
  description: Localized;
  price: number;
  compareAtPrice: number | null;
  images: string[];
  modes: UnlockMode[];
  collections: Collection[];
  features: Localized<string[]>;
  variants: Variant[];
  stock: number;
  visible: boolean;
  featured: boolean;
  createdAt: string;
  updatedAt: string;
}

/** Version allégée transmise aux composants client (sans description HTML). */
export type ProductSummary = Omit<Product, 'description' | 'createdAt' | 'updatedAt'>;

export function toSummary(p: Product): ProductSummary {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { description, createdAt, updatedAt, ...rest } = p;
  return rest;
}

export function isLocale(value: string | undefined | null): value is Locale {
  return !!value && (LOCALES as readonly string[]).includes(value);
}

export const ORDER_STATUSES = ['new', 'confirmed', 'delivered', 'cancelled'] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export interface OrderItem {
  productId: string;
  name: string;
  variant: string | null;
  unitPrice: number;
  qty: number;
}

export interface Order {
  id: string;
  status: OrderStatus;
  locale: Locale;
  customer: { name: string; phone: string; city: string; address: string; note: string };
  items: OrderItem[];
  total: number;
  createdAt: string;
  updatedAt: string;
}

/** Numéro marocain : 06/07/05 ou +212 / 00212. */
export function normalizeMoroccanPhone(input: string): string | null {
  const digits = input.replace(/[\s.\-()]/g, '');
  const m = /^(?:\+212|00212|0)([5-7]\d{8})$/.exec(digits);
  return m ? `0${m[1]}` : null;
}
