import type { MetadataRoute } from 'next';
import { readProducts } from '@/lib/catalog';
import { LOCALES } from '@/lib/types';
import { SITE } from '@/lib/site';

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = (await readProducts()).filter((p) => p.visible);
  const pages = ['', '/serrures', '/compatibilite', '/contact'];
  const now = new Date();
  return LOCALES.flatMap((l) => [
    ...pages.map((p) => ({
      url: `${SITE.url}/${l}${p}`,
      lastModified: now,
      changeFrequency: 'weekly' as const,
      priority: p === '' ? 1 : 0.8,
    })),
    ...products.map((p) => ({
      url: `${SITE.url}/${l}/serrures/${p.slug}`,
      lastModified: new Date(p.updatedAt),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    })),
  ]);
}
