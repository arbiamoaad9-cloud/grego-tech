import type { Metadata, Viewport } from 'next';
import { Inter, Sora, Tajawal } from 'next/font/google';
import './globals.css';
import { SITE } from '@/lib/site';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });
const sora = Sora({ subsets: ['latin'], weight: ['600', '700', '800'], variable: '--font-display', display: 'swap' });
const tajawal = Tajawal({
  subsets: ['arabic'],
  weight: ['400', '500', '700', '800'],
  variable: '--font-ar',
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  icons: { icon: '/icon.svg' },
};

export const viewport: Viewport = {
  themeColor: '#0B63F6',
  width: 'device-width',
  initialScale: 1,
};

// Applique la langue et le sens d'écriture avant l'affichage (évite tout clignotement en arabe)
const LANG_SCRIPT =
  "(function(){try{var l=location.pathname.split('/')[1];var d=document.documentElement;if(l==='ar'){d.lang='ar';d.dir='rtl';}else{d.lang='fr';d.dir='ltr';}}catch(e){}})();";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" dir="ltr" suppressHydrationWarning className={`${inter.variable} ${sora.variable} ${tajawal.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: LANG_SCRIPT }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
