import type { Metadata } from 'next';
import './admin.css';

export const metadata: Metadata = {
  title: 'Administration — Grego Tech',
  robots: { index: false, follow: false, nocache: true },
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="admin-body" lang="fr" dir="ltr">
      {children}
    </div>
  );
}
