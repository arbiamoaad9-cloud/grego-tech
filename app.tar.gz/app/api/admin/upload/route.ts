import { NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';
import { DATA_DIR } from '@/lib/data-dir';
import crypto from 'crypto';
import { guardAdmin } from '@/lib/admin-guard';

export const dynamic = 'force-dynamic';

const MAX_SIZE = 12 * 1024 * 1024;
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

/** Détection du format réel par signature binaire (et non par l'extension déclarée). */
function sniff(buf: Buffer): 'jpg' | 'png' | 'webp' | 'avif' | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  if (buf.toString('ascii', 4, 8) === 'ftyp' && /avi[fs]/.test(buf.toString('ascii', 8, 12))) return 'avif';
  return null;
}

export async function POST(req: Request) {
  const denied = await guardAdmin(req);
  if (denied) return denied;

  const form = await req.formData().catch(() => null);
  const file = form?.get('file');
  if (!file || typeof file === 'string') return NextResponse.json({ error: 'Aucun fichier' }, { status: 400 });
  if (file.size > MAX_SIZE) return NextResponse.json({ error: 'Image trop lourde (12 Mo max)' }, { status: 413 });

  const buf = Buffer.from(await file.arrayBuffer());
  const ext = sniff(buf);
  if (!ext) return NextResponse.json({ error: 'Format non supporté (JPG, PNG, WEBP, AVIF)' }, { status: 415 });

  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const base = `${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;

  // Optimisation : redimensionnement (1600 px max) et conversion WebP ; sinon fichier d'origine
  let out = buf;
  let finalExt: string = ext;
  try {
    const sharp = (await import('sharp')).default;
    out = await sharp(buf).rotate().resize({ width: 1600, height: 1600, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
    finalExt = 'webp';
  } catch {
    /* sharp indisponible : image conservée telle quelle */
  }
  const name = `${base}.${finalExt}`;
  await fs.writeFile(path.join(UPLOAD_DIR, name), out);
  return NextResponse.json({ url: `/api/media/${name}` }, { status: 201 });
}
