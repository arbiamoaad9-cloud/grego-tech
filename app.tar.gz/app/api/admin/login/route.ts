import { NextResponse } from 'next/server';
import { SESSION_COOKIE, SESSION_TTL_MS, checkPassword, createSessionToken, getAuthSecret, isSameOrigin } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const attempts = new Map<string, { count: number; first: number }>();

function clientIp(req: Request): string {
  return (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || req.headers.get('x-real-ip') || 'local';
}

export async function POST(req: Request) {
  if (!isSameOrigin(req)) {
    return NextResponse.json({ error: 'Requête refusée' }, { status: 403 });
  }
  if (!process.env.ADMIN_PASSWORD || !getAuthSecret()) {
    return NextResponse.json(
      { error: 'Configuration manquante : définissez ADMIN_PASSWORD et ADMIN_SECRET dans .env.local' },
      { status: 503 },
    );
  }

  const ip = clientIp(req);
  const now = Date.now();
  const entry = attempts.get(ip);
  if (entry && now - entry.first < WINDOW_MS && entry.count >= MAX_ATTEMPTS) {
    const wait = Math.ceil((WINDOW_MS - (now - entry.first)) / 60000);
    return NextResponse.json({ error: `Trop de tentatives. Réessayez dans ${wait} min.` }, { status: 429 });
  }

  let password = '';
  try {
    const body = (await req.json()) as { password?: unknown };
    password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
  } catch {
    return NextResponse.json({ error: 'Requête invalide' }, { status: 400 });
  }

  const ok = await checkPassword(password);
  if (!ok) {
    const e = entry && now - entry.first < WINDOW_MS ? entry : { count: 0, first: now };
    e.count += 1;
    attempts.set(ip, e);
    await new Promise((r) => setTimeout(r, 400));
    return NextResponse.json({ error: 'Mot de passe incorrect' }, { status: 401 });
  }

  attempts.delete(ip);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, await createSessionToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production' && process.env.ADMIN_INSECURE_COOKIE !== '1',
    sameSite: 'strict',
    path: '/',
    maxAge: Math.floor(SESSION_TTL_MS / 1000),
  });
  return res;
}
