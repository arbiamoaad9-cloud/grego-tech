import { NextResponse } from 'next/server';
import { guardAdmin } from '@/lib/admin-guard';
import { readOrders } from '@/lib/orders';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  return NextResponse.json({ orders: await readOrders() });
}
