import { NextResponse } from 'next/server';
import { guardAdmin } from '@/lib/admin-guard';
import { mutateOrders } from '@/lib/orders';
import { ORDER_STATUSES, type Order, type OrderStatus } from '@/lib/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: { id: string } };
const idOk = (id: string) => /^GT-\d{8}-[A-Z0-9]{4}$/.test(id);

export async function PATCH(req: Request, { params }: Ctx) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  if (!idOk(params.id)) return NextResponse.json({ error: 'Identifiant invalide' }, { status: 400 });
  const body = (await req.json().catch(() => ({}))) as { status?: string };
  if (!body.status || !(ORDER_STATUSES as readonly string[]).includes(body.status)) {
    return NextResponse.json({ error: 'Statut invalide' }, { status: 400 });
  }
  const updated = await mutateOrders<Order | null>((orders) => {
    const o = orders.find((x) => x.id === params.id);
    if (!o) return { next: orders, result: null };
    o.status = body.status as OrderStatus;
    o.updatedAt = new Date().toISOString();
    return { next: orders, result: o };
  });
  if (!updated) return NextResponse.json({ error: 'Commande introuvable' }, { status: 404 });
  return NextResponse.json({ order: updated });
}

export async function DELETE(req: Request, { params }: Ctx) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  if (!idOk(params.id)) return NextResponse.json({ error: 'Identifiant invalide' }, { status: 400 });
  const removed = await mutateOrders((orders) => {
    const next = orders.filter((o) => o.id !== params.id);
    return { next, result: next.length !== orders.length };
  });
  if (!removed) return NextResponse.json({ error: 'Commande introuvable' }, { status: 404 });
  return NextResponse.json({ ok: true });
}
