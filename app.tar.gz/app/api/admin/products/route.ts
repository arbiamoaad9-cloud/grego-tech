import { NextResponse } from 'next/server';
import { guardAdmin } from '@/lib/admin-guard';
import { mutateProducts, readProducts } from '@/lib/catalog';
import { buildProduct, productInputSchema } from '@/lib/validation';
import { refreshStorefront } from '@/lib/revalidate';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  return NextResponse.json({ products: await readProducts() });
}

export async function POST(req: Request) {
  const denied = await guardAdmin(req);
  if (denied) return denied;

  const parsed = productInputSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Données invalides', issues: parsed.error.flatten() }, { status: 422 });
  }

  const created = await mutateProducts((products) => {
    const product = buildProduct(parsed.data);
    let slug = product.slug;
    let n = 2;
    while (products.some((p) => p.slug === slug)) slug = `${product.slug}-${n++}`;
    product.slug = slug;
    return { next: [product, ...products], result: product };
  });

  refreshStorefront();
  return NextResponse.json({ product: created }, { status: 201 });
}
