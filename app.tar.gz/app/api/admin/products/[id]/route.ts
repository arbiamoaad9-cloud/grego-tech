import { NextResponse } from 'next/server';
import { guardAdmin } from '@/lib/admin-guard';
import { mutateProducts } from '@/lib/catalog';
import { buildProduct, productInputSchema } from '@/lib/validation';
import { refreshStorefront } from '@/lib/revalidate';
import type { Product } from '@/lib/types';

export const dynamic = 'force-dynamic';

type Ctx = { params: { id: string } };

const idOk = (id: string) => /^[0-9a-z-]{1,40}$/i.test(id);

export async function PUT(req: Request, { params }: Ctx) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  if (!idOk(params.id)) return NextResponse.json({ error: 'Identifiant invalide' }, { status: 400 });

  const parsed = productInputSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Données invalides', issues: parsed.error.flatten() }, { status: 422 });
  }

  const updated = await mutateProducts<Product | null>((products) => {
    const idx = products.findIndex((p) => p.id === params.id);
    if (idx === -1) return { next: products, result: null };
    const product = buildProduct(parsed.data, products[idx]);
    if (products.some((p, i) => i !== idx && p.slug === product.slug)) product.slug = `${product.slug}-${product.id.slice(-4)}`;
    products[idx] = product;
    return { next: products, result: product };
  });

  if (!updated) return NextResponse.json({ error: 'Produit introuvable' }, { status: 404 });
  refreshStorefront();
  return NextResponse.json({ product: updated });
}

/** Mise à jour rapide : visibilité, mise en avant ou stock. */
export async function PATCH(req: Request, { params }: Ctx) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  if (!idOk(params.id)) return NextResponse.json({ error: 'Identifiant invalide' }, { status: 400 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const patch: Partial<Pick<Product, 'visible' | 'featured' | 'stock'>> = {};
  if (typeof body.visible === 'boolean') patch.visible = body.visible;
  if (typeof body.featured === 'boolean') patch.featured = body.featured;
  if (typeof body.stock === 'number' && Number.isInteger(body.stock) && body.stock >= 0 && body.stock <= 100000) patch.stock = body.stock;
  if (!Object.keys(patch).length) return NextResponse.json({ error: 'Aucune modification' }, { status: 400 });

  const updated = await mutateProducts<Product | null>((products) => {
    const p = products.find((x) => x.id === params.id);
    if (!p) return { next: products, result: null };
    Object.assign(p, patch, { updatedAt: new Date().toISOString() });
    return { next: products, result: p };
  });

  if (!updated) return NextResponse.json({ error: 'Produit introuvable' }, { status: 404 });
  refreshStorefront();
  return NextResponse.json({ product: updated });
}

export async function DELETE(req: Request, { params }: Ctx) {
  const denied = await guardAdmin(req);
  if (denied) return denied;
  if (!idOk(params.id)) return NextResponse.json({ error: 'Identifiant invalide' }, { status: 400 });

  const removed = await mutateProducts((products) => {
    const next = products.filter((p) => p.id !== params.id);
    return { next, result: next.length !== products.length };
  });

  if (!removed) return NextResponse.json({ error: 'Produit introuvable' }, { status: 404 });
  refreshStorefront();
  return NextResponse.json({ ok: true });
}
