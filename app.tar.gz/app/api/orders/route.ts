import { NextResponse } from 'next/server';
import { z } from 'zod';
import { isSameOrigin } from '@/lib/auth';
import { readProducts } from '@/lib/catalog';
import { mutateOrders, newOrderId } from '@/lib/orders';
import { cleanText } from '@/lib/sanitize';
import { normalizeMoroccanPhone, type Order } from '@/lib/types';

export const dynamic = 'force-dynamic';

const WINDOW_MS = 60 * 60 * 1000;
const MAX_ORDERS_PER_WINDOW = 8;
const hits = new Map<string, number[]>();

const schema = z.object({
  locale: z.enum(['fr', 'ar']).default('fr'),
  customer: z.object({
    name: z.string().max(160),
    phone: z.string().max(40),
    city: z.string().max(120),
    address: z.string().max(600),
    note: z.string().max(1000).optional().default(''),
  }),
  items: z
    .array(z.object({ id: z.string().max(40), variantId: z.string().max(40).nullable(), qty: z.number().int().min(1).max(20) }))
    .min(1)
    .max(30),
});

export async function POST(req: Request) {
  if (!isSameOrigin(req)) return NextResponse.json({ error: 'Requête refusée' }, { status: 403 });

  // Limitation anti-abus par adresse IP
  const ip = (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || 'local';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_ORDERS_PER_WINDOW) {
    return NextResponse.json({ error: 'Trop de commandes, réessayez plus tard.' }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'Données invalides' }, { status: 422 });
  const { locale, customer, items } = parsed.data;

  const name = cleanText(customer.name, 80);
  const city = cleanText(customer.city, 60);
  const address = cleanText(customer.address, 300);
  const note = cleanText(customer.note, 500);
  const phone = normalizeMoroccanPhone(customer.phone);
  if (name.length < 2 || city.length < 2 || address.length < 8 || !phone) {
    return NextResponse.json({ error: 'Coordonnées incomplètes' }, { status: 422 });
  }

  // Prix recalculés côté serveur depuis le catalogue (jamais ceux envoyés par le navigateur)
  const catalog = (await readProducts()).filter((p) => p.visible);
  const lines: Order['items'] = [];
  for (const it of items) {
    const p = catalog.find((x) => x.id === it.id);
    if (!p) return NextResponse.json({ error: 'Produit indisponible' }, { status: 422 });
    const v = it.variantId ? p.variants.find((x) => x.id === it.variantId) ?? null : null;
    lines.push({
      productId: p.id,
      name: p.name.fr,
      variant: v ? v.label.fr : null,
      unitPrice: v?.price ?? p.price,
      qty: it.qty,
    });
  }
  const total = lines.reduce((n, l) => n + l.unitPrice * l.qty, 0);

  const order = await mutateOrders((orders) => {
    const stamp = new Date().toISOString();
    const o: Order = {
      id: newOrderId(orders),
      status: 'new',
      locale,
      customer: { name, phone, city, address, note },
      items: lines,
      total,
      createdAt: stamp,
      updatedAt: stamp,
    };
    return { next: [o, ...orders], result: o };
  });

  recent.push(now);
  hits.set(ip, recent);
  return NextResponse.json({ id: order.id, total: order.total }, { status: 201 });
}
