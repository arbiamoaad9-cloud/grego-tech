import { promises as fs } from 'fs';
import path from 'path';
import { DATA_DIR } from '@/lib/data-dir';

export const dynamic = 'force-dynamic';

const TYPES: Record<string, string> = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', avif: 'image/avif' };
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

export async function GET(_req: Request, { params }: { params: { file: string } }) {
  const m = /^([a-z0-9]+-[a-f0-9]{12})\.(jpg|png|webp|avif)$/.exec(params.file);
  if (!m) return new Response('Not found', { status: 404 });
  try {
    const data = await fs.readFile(path.join(UPLOAD_DIR, params.file));
    return new Response(new Uint8Array(data), {
      headers: {
        'Content-Type': TYPES[m[2]],
        'Cache-Control': 'public, max-age=31536000, immutable',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch {
    return new Response('Not found', { status: 404 });
  }
}
