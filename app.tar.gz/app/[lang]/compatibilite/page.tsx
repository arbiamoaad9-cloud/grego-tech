import type { Metadata } from 'next';
import Link from 'next/link';
import { ChevronRight, DoorOpen, Droplets, MoveHorizontal, Ruler, type LucideIcon } from 'lucide-react';
import DoorCheck from '@/components/home/DoorCheck';
import Reveal from '@/components/ui/Reveal';
import { getDictionary } from '@/lib/i18n';
import { isLocale, type Locale } from '@/lib/types';

const ICONS: LucideIcon[] = [Ruler, DoorOpen, MoveHorizontal, Droplets];

export function generateMetadata({ params }: { params: { lang: string } }): Metadata {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  return {
    title: dict.meta.compatTitle,
    description: dict.doorCheck.subtitle,
    alternates: { canonical: `/${locale}/compatibilite` },
  };
}

export default function CompatPage({ params }: { params: { lang: string } }) {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  const c = dict.compat;

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <nav className="breadcrumb" aria-label="Fil d'Ariane">
            <Link href={`/${locale}`}>{dict.nav.home}</Link>
            <ChevronRight className="flip-rtl" aria-hidden="true" />
            <span aria-current="page">{dict.nav.compatibility}</span>
          </nav>
          <span className="eyebrow">{c.eyebrow}</span>
          <h1 className="title">{c.title}</h1>
          <p className="lead">{c.subtitle}</p>
        </div>
      </section>
      <section className="container" style={{ paddingBottom: 96 }}>
        <div className="checks">
          {c.checks.map((item, i) => {
            const Icon = ICONS[i % ICONS.length];
            return (
              <Reveal key={item.title} delay={i * 0.06} className="check-card">
                <span className="guarantee__icon">
                  <Icon aria-hidden="true" />
                </span>
                <div>
                  <h3>{item.title}</h3>
                  <p>{item.desc}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
        <DoorCheck />
      </section>
    </>
  );
}
