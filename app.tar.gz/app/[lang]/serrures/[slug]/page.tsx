import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { BadgeCheck, ChevronRight, CircleCheck, ShieldCheck, Truck, Wrench } from 'lucide-react';
import ProductGallery from '@/components/products/ProductGallery';
import ProductPurchase from '@/components/products/ProductPurchase';
import ProductCard from '@/components/products/ProductCard';
import ModeList from '@/components/products/ModeList';
import DoorCheck from '@/components/home/DoorCheck';
import { getProductBySlug, getVisibleProducts, readProducts } from '@/lib/catalog';
import { discountPercent, formatPrice } from '@/lib/format';
import { getDictionary, t } from '@/lib/i18n';
import { sanitizeDescription } from '@/lib/validation';
import { LOCALES, isLocale, toSummary, type Locale } from '@/lib/types';
import { SITE } from '@/lib/site';

export const revalidate = 300;
export const dynamicParams = true;

export async function generateStaticParams() {
  const products = (await readProducts()).filter((p) => p.visible);
  return LOCALES.flatMap((lang) => products.map((p) => ({ lang, slug: p.slug })));
}

export async function generateMetadata({ params }: { params: { lang: string; slug: string } }): Promise<Metadata> {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const product = await getProductBySlug(params.slug);
  if (!product || !product.visible) return {};
  const title = product.name[locale];
  return {
    title,
    description: product.shortDescription[locale],
    alternates: {
      canonical: `/${locale}/serrures/${product.slug}`,
      languages: { fr: `/fr/serrures/${product.slug}`, ar: `/ar/serrures/${product.slug}` },
    },
    openGraph: { title, description: product.shortDescription[locale], images: product.images.slice(0, 1) },
  };
}

export default async function ProductPage({ params }: { params: { lang: string; slug: string } }) {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  const product = await getProductBySlug(params.slug);
  if (!product || !product.visible) notFound();

  const name = product.name[locale];
  const off = discountPercent(product.price, product.compareAtPrice);
  const related = (await getVisibleProducts())
    .filter((p) => p.id !== product.id && p.collections.some((c) => product.collections.includes(c)))
    .slice(0, 4)
    .map(toSummary);

  const stockLabel =
    product.stock <= 0
      ? { text: dict.product.outOfStock, color: '#b77100' }
      : product.stock <= 3
        ? { text: t(dict.product.lowStock, { count: product.stock }), color: '#e5484d' }
        : { text: dict.product.inStock, color: '#0d9b54' };

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name,
    sku: product.sku || product.id,
    image: product.images,
    description: product.shortDescription[locale],
    brand: { '@type': 'Brand', name: SITE.name },
    offers: {
      '@type': 'Offer',
      priceCurrency: 'MAD',
      price: product.price,
      availability: product.stock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/PreOrder',
      url: `${SITE.url}/${locale}/serrures/${product.slug}`,
    },
  };

  return (
    <>
      <div className="container" style={{ paddingTop: 28 }}>
        <nav className="breadcrumb" aria-label="Fil d'Ariane">
          <Link href={`/${locale}`}>{dict.nav.home}</Link>
          <ChevronRight className="flip-rtl" aria-hidden="true" />
          <Link href={`/${locale}/serrures`}>{dict.nav.locks}</Link>
          <ChevronRight className="flip-rtl" aria-hidden="true" />
          <span aria-current="page">{name}</span>
        </nav>

        <div className="pdp">
          <ProductGallery images={product.images} name={name} badge={off ? `-${off}%` : null} />

          <div className="pdp__info">
            <div>
              <span className="pdp__stock" style={{ color: stockLabel.color }}>
                {stockLabel.text}
              </span>
              <h1 className="pdp__title" style={{ marginTop: 10 }}>
                {name}
              </h1>
              <p className="lead" style={{ marginTop: 10 }}>
                {product.shortDescription[locale]}
              </p>
            </div>

            <div className="price pdp__price">
              <span className="price__now">{formatPrice(product.price, locale)}</span>
              {product.compareAtPrice && (
                <>
                  <span className="price__old">{formatPrice(product.compareAtPrice, locale)}</span>
                  <span className="pdp__save">
                    {t(dict.product.save, { amount: formatPrice(product.compareAtPrice - product.price, locale) })}
                  </span>
                </>
              )}
            </div>

            <div>
              <p className="label" style={{ marginBottom: 10 }}>
                {dict.product.modes}
              </p>
              <ModeList modes={product.modes} labels={dict.modes} labeled />
            </div>

            <ProductPurchase product={toSummary(product)} />

            <div className="pdp__trust">
              <span className="trust">
                <Wrench aria-hidden="true" />
                {dict.product.freeInstall}
              </span>
              <span className="trust">
                <ShieldCheck aria-hidden="true" />
                {dict.product.warranty}
              </span>
              <span className="trust">
                <Truck aria-hidden="true" />
                {dict.product.delivery}
              </span>
              <span className="trust">
                <BadgeCheck aria-hidden="true" />
                {dict.product.cod}
              </span>
            </div>

            {product.features[locale].length > 0 && (
              <div className="panel">
                <h2>{dict.product.features}</h2>
                <ul className="feature-list">
                  {product.features[locale].map((f) => (
                    <li key={f}>
                      <CircleCheck aria-hidden="true" />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="panel">
              <h2>{dict.product.description}</h2>
              <div
                className="prose"
                // HTML assaini à l'enregistrement et à nouveau ici (liste blanche de balises, sans attributs)
                dangerouslySetInnerHTML={{ __html: sanitizeDescription(product.description[locale]) }}
              />
            </div>
          </div>
        </div>
      </div>

      {related.length > 0 && (
        <section className="section section--tint">
          <div className="container">
            <div className="section__head">
              <h2 className="title">{dict.product.related}</h2>
            </div>
            <div className="product-grid">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="section">
        <div className="container">
          <DoorCheck compact />
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }}
      />
    </>
  );
}
