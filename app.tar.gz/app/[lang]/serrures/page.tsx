import type { Metadata } from 'next';
import { Suspense } from 'react';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import ProductGrid from '@/components/products/ProductGrid';
import { getVisibleProducts } from '@/lib/catalog';
import { getDictionary } from '@/lib/i18n';
import { isLocale, toSummary, type Locale } from '@/lib/types';

export const revalidate = 300;

export function generateMetadata({ params }: { params: { lang: string } }): Metadata {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  return {
    title: dict.meta.catalogTitle,
    description: dict.catalog.subtitle,
    alternates: { canonical: `/${locale}/serrures`, languages: { fr: '/fr/serrures', ar: '/ar/serrures' } },
  };
}

export default async function CatalogPage({ params }: { params: { lang: string } }) {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  const products = (await getVisibleProducts()).map(toSummary);

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <nav className="breadcrumb" aria-label="Fil d'Ariane">
            <Link href={`/${locale}`}>{dict.nav.home}</Link>
            <ChevronRight className="flip-rtl" aria-hidden="true" />
            <span aria-current="page">{dict.nav.locks}</span>
          </nav>
          <span className="eyebrow">{dict.catalog.eyebrow}</span>
          <h1 className="title">{dict.catalog.title}</h1>
          <p className="lead">{dict.catalog.subtitle}</p>
        </div>
      </section>
      <div className="container">
        <Suspense fallback={<div className="product-grid" style={{ minHeight: 600 }} />}>
          <ProductGrid products={products} />
        </Suspense>
      </div>
    </>
  );
}
