'use client';

import Link from 'next/link';
import { useLocale } from '@/components/i18n/LocaleProvider';

export default function NotFound() {
  const { locale, dict } = useLocale();
  return (
    <section className="notfound">
      <div>
        <strong className="gradient-text">404</strong>
        <h1 className="title" style={{ marginTop: 12 }}>
          {dict.notFound.title}
        </h1>
        <p className="lead">{dict.notFound.text}</p>
        <Link href={`/${locale}`} className="btn btn--primary" style={{ marginTop: 24 }}>
          {dict.notFound.back}
        </Link>
      </div>
    </section>
  );
}
