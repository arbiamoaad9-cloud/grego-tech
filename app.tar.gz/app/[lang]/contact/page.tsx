import type { Metadata } from 'next';
import Link from 'next/link';
import { ChevronRight, Clock, Mail, MapPin, Phone } from 'lucide-react';
import ContactForm from '@/components/home/ContactForm';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { getDictionary } from '@/lib/i18n';
import { isLocale, type Locale } from '@/lib/types';
import { SITE, whatsappUrl } from '@/lib/site';

export function generateMetadata({ params }: { params: { lang: string } }): Metadata {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  return {
    title: dict.meta.contactTitle,
    description: dict.contact.subtitle,
    alternates: { canonical: `/${locale}/contact` },
  };
}

export default function ContactPage({ params }: { params: { lang: string } }) {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  const c = dict.contact;

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <nav className="breadcrumb" aria-label="Fil d'Ariane">
            <Link href={`/${locale}`}>{dict.nav.home}</Link>
            <ChevronRight className="flip-rtl" aria-hidden="true" />
            <span aria-current="page">{dict.nav.contact}</span>
          </nav>
          <span className="eyebrow">{c.eyebrow}</span>
          <h1 className="title">{c.title}</h1>
          <p className="lead">{c.subtitle}</p>
        </div>
      </section>
      <div className="container contact">
        <div className="info-list">
          <h2 className="label" style={{ fontSize: 15 }}>
            {c.info}
          </h2>
          <a className="info-card" href={whatsappUrl()} target="_blank" rel="noopener noreferrer">
            <span className="info-card__icon info-card__icon--wa">
              <WhatsAppIcon />
            </span>
            <span>
              <small>{c.whatsapp}</small>
              <strong dir="ltr">{SITE.phoneDisplay}</strong>
            </span>
          </a>
          <a className="info-card" href={`tel:+${SITE.whatsapp}`}>
            <span className="info-card__icon">
              <Phone />
            </span>
            <span>
              <small>{c.phoneLabel}</small>
              <strong dir="ltr">{SITE.phoneDisplay}</strong>
            </span>
          </a>
          {SITE.email && (
            <a className="info-card" href={`mailto:${SITE.email}`}>
              <span className="info-card__icon">
                <Mail />
              </span>
              <span>
                <small>{c.emailLabel}</small>
                <strong>{SITE.email}</strong>
              </span>
            </a>
          )}
          <div className="info-card">
            <span className="info-card__icon">
              <MapPin />
            </span>
            <span>
              <small>{c.area}</small>
              <strong>{c.areaValue}</strong>
            </span>
          </div>
          <div className="info-card">
            <span className="info-card__icon">
              <Clock />
            </span>
            <span>
              <small>{c.support}</small>
              <strong>{c.supportValue}</strong>
            </span>
          </div>
        </div>
        <ContactForm />
      </div>
    </>
  );
}
