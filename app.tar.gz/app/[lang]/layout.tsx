import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import AnnouncementBar from '@/components/layout/AnnouncementBar';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import WhatsAppFloat from '@/components/layout/WhatsAppFloat';
import { CartProvider } from '@/components/cart/CartProvider';
import CartDrawer from '@/components/cart/CartDrawer';
import { LocaleProvider } from '@/components/i18n/LocaleProvider';
import HtmlLang from '@/components/i18n/HtmlLang';
import { dir, getDictionary } from '@/lib/i18n';
import { LOCALES, isLocale, type Locale } from '@/lib/types';
import { SITE } from '@/lib/site';

export function generateStaticParams() {
  return LOCALES.map((lang) => ({ lang }));
}

export function generateMetadata({ params }: { params: { lang: string } }): Metadata {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  return {
    title: { default: dict.meta.title, template: `%s | ${SITE.name}` },
    description: dict.meta.description,
    applicationName: SITE.name,
    authors: [{ name: SITE.legalName }],
    creator: SITE.legalName,
    alternates: {
      canonical: `/${locale}`,
      languages: { fr: '/fr', ar: '/ar', 'x-default': '/fr' },
    },
    openGraph: {
      type: 'website',
      siteName: SITE.name,
      title: dict.meta.title,
      description: dict.meta.description,
      locale: locale === 'ar' ? 'ar_MA' : 'fr_MA',
      url: `/${locale}`,
    },
    twitter: { card: 'summary_large_image', title: dict.meta.title, description: dict.meta.description },
    robots: { index: true, follow: true },
    formatDetection: { telephone: false },
  };
}

export default function LocaleLayout({ children, params }: { children: React.ReactNode; params: { lang: string } }) {
  if (!isLocale(params.lang)) notFound();
  const locale = params.lang;
  const dict = getDictionary(locale);

  const orgJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Store',
    name: SITE.name,
    legalName: SITE.legalName,
    url: SITE.url,
    telephone: `+${SITE.whatsapp}`,
    areaServed: 'MA',
    currenciesAccepted: 'MAD',
    paymentAccepted: 'Cash',
  };

  return (
    <div className="site" lang={locale} dir={dir(locale)}>
      <HtmlLang locale={locale} />
        <a href="#main" className="skip-link">
          {locale === 'ar' ? 'انتقل إلى المحتوى' : 'Aller au contenu'}
        </a>
        <LocaleProvider locale={locale} dict={dict}>
          <CartProvider>
            <AnnouncementBar items={dict.announcement} />
            <Header />
            <main id="main">{children}</main>
            <Footer locale={locale} dict={dict} />
            <WhatsAppFloat />
            <CartDrawer />
          </CartProvider>
        </LocaleProvider>
        <script
          type="application/ld+json"
          // Données structurées statiques (aucune donnée utilisateur)
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd).replace(/</g, '\\u003c') }}
        />
    </div>
  );
}
