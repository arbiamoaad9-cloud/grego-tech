import Hero from '@/components/home/Hero';
import Guarantees from '@/components/home/Guarantees';
import Collections from '@/components/home/Collections';
import FeaturedProducts from '@/components/home/FeaturedProducts';
import LockAnatomy from '@/components/home/LockAnatomy';
import ComparisonTable from '@/components/home/ComparisonTable';
import DoorCheck from '@/components/home/DoorCheck';
import Faq from '@/components/home/Faq';
import CtaBand from '@/components/home/CtaBand';
import Reveal from '@/components/ui/Reveal';
import { getVisibleProducts } from '@/lib/catalog';
import { getDictionary } from '@/lib/i18n';
import { COLLECTIONS, isLocale, toSummary, type Collection, type Locale } from '@/lib/types';

export const revalidate = 300;

export default async function HomePage({ params }: { params: { lang: string } }) {
  const locale: Locale = isLocale(params.lang) ? params.lang : 'fr';
  const dict = getDictionary(locale);
  const products = await getVisibleProducts();

  const featured = [...products.filter((p) => p.featured), ...products.filter((p) => !p.featured)].slice(0, 8);
  const covers: Partial<Record<Collection, string>> = {};
  for (const col of COLLECTIONS) {
    const p = products.find((x) => x.collections.includes(col) && x.featured) ?? products.find((x) => x.collections.includes(col));
    if (p?.images[0]) covers[col] = p.images[0];
  }

  const faqJsonLd = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: dict.faq.items.map((f) => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  };

  return (
    <>
      <Hero locale={locale} dict={dict} />
      <Guarantees dict={dict} />
      <Collections locale={locale} dict={dict} covers={covers} />
      <FeaturedProducts locale={locale} dict={dict} products={featured.map(toSummary)} />
      <LockAnatomy />
      <ComparisonTable dict={dict} />
      <section className="section">
        <div className="container">
          <DoorCheck />
        </div>
      </section>
      <section className="section section--tint" id="faq">
        <div className="container">
          <Reveal className="section__head section__head--center">
            <span className="eyebrow">{dict.faq.eyebrow}</span>
            <h2 className="title">{dict.faq.title}</h2>
          </Reveal>
          <Faq items={dict.faq.items} />
        </div>
      </section>
      <div style={{ paddingTop: 96 }}>
        <CtaBand dict={dict} />
      </div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd).replace(/</g, '\\u003c') }}
      />
    </>
  );
}
