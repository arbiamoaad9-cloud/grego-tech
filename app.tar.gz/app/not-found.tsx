import Link from 'next/link';

export default function GlobalNotFound() {
  return (
    <section className="notfound">
      <div>
        <strong className="gradient-text">404</strong>
        <h1 className="title" style={{ marginTop: 12 }}>
          Page introuvable
        </h1>
        <p className="lead">La page demandée n&apos;existe pas ou a été déplacée.</p>
        <Link href="/fr" className="btn btn--primary" style={{ marginTop: 24 }}>
          Retour à l&apos;accueil
        </Link>
      </div>
    </section>
  );
}
