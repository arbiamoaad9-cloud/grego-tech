import { Fragment } from 'react';
import { ShieldCheck, Truck, Wrench } from 'lucide-react';

const ICONS = [Truck, Wrench, ShieldCheck];

export default function AnnouncementBar({ items }: { items: string[] }) {
  return (
    <div className="announce" role="region" aria-label="Informations">
      <div className="container announce__inner">
        {items.map((text, i) => {
          const Icon = ICONS[i % ICONS.length];
          return (
            <Fragment key={text}>
              {i > 0 && <span className="announce__dot" aria-hidden="true" />}
              <span className="announce__item">
                <Icon aria-hidden="true" />
                {text}
              </span>
            </Fragment>
          );
        })}
      </div>
    </div>
  );
}
