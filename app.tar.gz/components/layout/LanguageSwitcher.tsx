'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { LOCALE_COOKIE, type Locale } from '@/lib/types';

const LABELS: Record<Locale, string> = { fr: 'FR', ar: 'العربية' };

export default function LanguageSwitcher({ locale, label }: { locale: Locale; label: string }) {
  const pathname = usePathname() || `/${locale}`;
  const search = useSearchParams();
  const qs = search?.toString();

  const hrefFor = (target: Locale) => {
    const parts = pathname.split('/');
    parts[1] = target;
    return `${parts.join('/') || `/${target}`}${qs ? `?${qs}` : ''}`;
  };

  const remember = (target: Locale) => {
    document.cookie = `${LOCALE_COOKIE}=${target}; path=/; max-age=31536000; samesite=lax`;
  };

  return (
    <nav className="lang-switch" aria-label={label}>
      {(Object.keys(LABELS) as Locale[]).map((l) => (
        <Link
          key={l}
          href={hrefFor(l)}
          lang={l}
          hrefLang={l}
          className={l === locale ? 'is-active' : undefined}
          aria-current={l === locale ? 'true' : undefined}
          onClick={() => remember(l)}
          prefetch={false}
        >
          {LABELS[l]}
        </Link>
      ))}
    </nav>
  );
}
