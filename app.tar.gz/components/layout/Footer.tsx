import Link from 'next/link';
import Image from 'next/image';
import { BadgeCheck, Mail, MapPin, Phone, ShieldCheck, Truck, Wrench } from 'lucide-react';
import Logo from './Logo';
import { WhatsAppIcon } from '@/components/ui/Icons';
import type { Dictionary } from '@/lib/i18n';
import type { Locale } from '@/lib/types';
import { SITE, whatsappUrl } from '@/lib/site';

export default function Footer({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const year = new Date().getFullYear();
  const c = dict.collections.items;
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <Logo locale={locale} light />
          <p className="footer__about">{dict.footer.about}</p>
          <div className="footer__trust">
            <span>
              <Truck aria-hidden="true" />
              {dict.footer.zone}
            </span>
            <span>
              <Wrench aria-hidden="true" />
              {dict.product.freeInstall}
            </span>
            <span>
              <ShieldCheck aria-hidden="true" />
              {dict.product.warranty}
            </span>
            <span>
              <BadgeCheck aria-hidden="true" />
              {dict.footer.payment}
            </span>
          </div>
        </div>

        <div>
          <h4>{dict.footer.shop}</h4>
          <ul>
            <li>
              <Link href={`/${locale}/serrures`}>{dict.footer.allLocks}</Link>
            </li>
            <li>
              <Link href={`/${locale}/serrures?collection=face-3d`}>{c['face-3d'].title}</Link>
            </li>
            <li>
              <Link href={`/${locale}/serrures?collection=handle`}>{c.handle.title}</Link>
            </li>
            <li>
              <Link href={`/${locale}/serrures?collection=apartment`}>{c.apartment.title}</Link>
            </li>
            <li>
              <Link href={`/${locale}/serrures?collection=waterproof`}>{c.waterproof.title}</Link>
            </li>
          </ul>
        </div>

        <div>
          <h4>{dict.footer.help}</h4>
          <ul>
            <li>
              <Link href={`/${locale}/compatibilite`}>{dict.nav.compatibility}</Link>
            </li>
            <li>
              <Link href={`/${locale}#faq`}>{dict.faq.title}</Link>
            </li>
            <li>
              <Link href={`/${locale}/contact`}>{dict.nav.contact}</Link>
            </li>
          </ul>
        </div>

        <div>
          <h4>{dict.footer.contact}</h4>
          <ul className="footer__contact">
            <li>
              <WhatsAppIcon className="wa-ico" />
              <a href={whatsappUrl()} target="_blank" rel="noopener noreferrer" dir="ltr">
                {SITE.phoneDisplay}
              </a>
            </li>
            <li>
              <Phone aria-hidden="true" />
              <a href={`tel:+${SITE.whatsapp}`} dir="ltr">
                {SITE.phoneDisplay}
              </a>
            </li>
            {SITE.email && (
              <li>
                <Mail aria-hidden="true" />
                <a href={`mailto:${SITE.email}`}>{SITE.email}</a>
              </li>
            )}
            <li>
              <MapPin aria-hidden="true" />
              {dict.contact.areaValue}
            </li>
          </ul>
        </div>
      </div>

      <div className="container footer__bottom">
        <span>
          © {year} {SITE.legalName} — {SITE.name}. {dict.footer.rights}
        </span>
        <span className="credit">
          <Image src={SITE.agency.icon} alt="Dar Digital" width={26} height={26} />
          <span>
            {dict.footer.madeBy} <strong>Dar Digital</strong>
          </span>
          <span className="credit__bars" aria-hidden="true">
            <i style={{ background: '#1A73E8' }} />
            <i style={{ background: '#EA4335' }} />
            <i style={{ background: '#FBBC04' }} />
            <i style={{ background: '#34A853' }} />
          </span>
        </span>
      </div>
    </footer>
  );
}
