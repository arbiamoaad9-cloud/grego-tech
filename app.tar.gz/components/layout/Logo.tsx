import Link from 'next/link';
import { GregoMark } from '@/components/ui/Icons';
import type { Locale } from '@/lib/types';

export default function Logo({ locale, light = false }: { locale: Locale; light?: boolean }) {
  return (
    <Link href={`/${locale}`} className="logo" aria-label="Grego Tech" dir="ltr">
      <GregoMark className="logo__mark" />
      <span className="logo__text">
        <span className="logo__name" style={light ? { color: '#fff' } : undefined}>
          GREGO
        </span>
        <span className="logo__sub gradient-text">TECH</span>
      </span>
    </Link>
  );
}
