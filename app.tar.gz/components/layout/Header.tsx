'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Suspense, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronRight, Menu, ShoppingBag, X } from 'lucide-react';
import Logo from './Logo';
import LanguageSwitcher from './LanguageSwitcher';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useCart } from '@/components/cart/CartProvider';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { whatsappUrl } from '@/lib/site';

export default function Header() {
  const { locale, dict } = useLocale();
  const pathname = usePathname() || '';
  const { count, open } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [pathname]);

  const links = [
    { href: `/${locale}`, label: dict.nav.home, exact: true },
    { href: `/${locale}/serrures`, label: dict.nav.locks },
    { href: `/${locale}/compatibilite`, label: dict.nav.compatibility },
    { href: `/${locale}/contact`, label: dict.nav.contact },
  ];
  const isActive = (href: string, exact?: boolean) => (exact ? pathname === href : pathname.startsWith(href));
  const waHref = whatsappUrl();

  return (
    <>
      <header className={`header${scrolled ? ' is-scrolled' : ''}`}>
        <div className="container header__inner">
          <Logo locale={locale} />

          <nav className="nav" aria-label="Navigation principale">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`nav__link${isActive(l.href, l.exact) ? ' is-active' : ''}`}
                aria-current={isActive(l.href, l.exact) ? 'page' : undefined}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="header__actions">
            <Suspense fallback={null}>
              <LanguageSwitcher locale={locale} label={dict.nav.language} />
            </Suspense>
            <a
              href={waHref}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--wa header__wa"
              aria-label={`${dict.nav.whatsapp} +212 648 70 18 85`}
            >
              <WhatsAppIcon />
              <span>{dict.nav.whatsapp}</span>
            </a>
            <button type="button" className="icon-btn" onClick={open} aria-label={dict.nav.cart}>
              <ShoppingBag />
              {count > 0 && <span className="cart-count">{count}</span>}
            </button>
            <button
              type="button"
              className="icon-btn burger"
              onClick={() => setMenuOpen(true)}
              aria-label={dict.nav.menu}
              aria-expanded={menuOpen}
            >
              <Menu />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="mobile-menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMenuOpen(false)}
          >
            <motion.nav
              className="mobile-menu__panel"
              initial={{ x: locale === 'ar' ? '-100%' : '100%' }}
              animate={{ x: 0 }}
              exit={{ x: locale === 'ar' ? '-100%' : '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              aria-label={dict.nav.menu}
            >
              <div className="mobile-menu__top">
                <Logo locale={locale} />
                <button type="button" className="icon-btn" onClick={() => setMenuOpen(false)} aria-label={dict.nav.close}>
                  <X />
                </button>
              </div>
              {links.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`mobile-menu__link${isActive(l.href, l.exact) ? ' is-active' : ''}`}
                >
                  {l.label}
                  <ChevronRight className="flip-rtl" width={20} height={20} />
                </Link>
              ))}
              <div className="mobile-menu__foot">
                <a href={waHref} target="_blank" rel="noopener noreferrer" className="btn btn--wa btn--block">
                  <WhatsAppIcon />
                  +212 648 70 18 85
                </a>
              </div>
            </motion.nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
