'use client';

import { WhatsAppIcon } from '@/components/ui/Icons';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { whatsappUrl } from '@/lib/site';

export default function WhatsAppFloat() {
  const { dict } = useLocale();
  return (
    <a
      className="wa-float"
      href={whatsappUrl(dict.cart.waIntro.replace(/:$/, '.'))}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`${dict.nav.whatsapp} +212 648 70 18 85`}
    >
      <WhatsAppIcon />
    </a>
  );
}
