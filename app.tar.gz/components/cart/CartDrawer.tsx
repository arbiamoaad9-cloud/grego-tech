'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CircleCheck, LoaderCircle, Minus, Plus, ShoppingBag, X } from 'lucide-react';
import { useCart } from './CartProvider';
import { useLocale } from '@/components/i18n/LocaleProvider';
import SmartImage from '@/components/ui/SmartImage';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { formatPrice } from '@/lib/format';
import { cleanText } from '@/lib/sanitize';
import { t } from '@/lib/i18n';
import { normalizeMoroccanPhone } from '@/lib/types';
import { whatsappUrl } from '@/lib/site';

export default function CartDrawer() {
  const { locale, dict } = useLocale();
  const { items, isOpen, close, setQty, remove, subtotal, toast, clear } = useCart();
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState<{ id: string; wa: string } | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, close]);

  const checkout = async () => {
    const n = cleanText(name, 80);
    const c = cleanText(city, 60);
    const adr = cleanText(address, 300);
    if (n.length < 2 || c.length < 2 || adr.length < 8 || !phone.trim()) {
      setError(dict.cart.required);
      return;
    }
    const p = normalizeMoroccanPhone(phone);
    if (!p) {
      setError(dict.cart.invalidPhone);
      return;
    }
    setError('');
    setSending(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          locale,
          customer: { name: n, phone: p, city: c, address: adr, note: cleanText(note, 500) },
          items: items.map((i) => ({ id: i.id, variantId: i.variant?.id ?? null, qty: i.qty })),
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { id?: string; total?: number };
      if (!res.ok || !data.id) throw new Error();
      const lines = items.map((i) => {
        const v = i.variant ? ` (${i.variant.label[locale]})` : '';
        return `• ${i.qty} × ${i.name[locale]}${v} — ${formatPrice(i.price * i.qty, locale)}`;
      });
      const msg = [
        `${dict.cart.waIntro}`,
        `${dict.cart.waOrder} : ${data.id}`,
        '',
        ...lines,
        '',
        `${dict.cart.waTotal} : ${formatPrice(data.total ?? subtotal, locale)} (${dict.cart.install} ${dict.cart.installFree.toLowerCase()})`,
        '',
        `${dict.cart.waCustomer} : ${n}`,
        `${dict.cart.waPhone} : ${p}`,
        `${dict.cart.waAddress} : ${adr}, ${c}`,
      ].join('\n');
      setDone({ id: data.id, wa: whatsappUrl(msg) });
      clear();
    } catch {
      setError(dict.cart.error);
    } finally {
      setSending(false);
    }
  };

  const closeAll = () => {
    setDone(null);
    close();
  };

  const slideFrom = locale === 'ar' ? '-100%' : '100%';

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              className="drawer-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeAll}
            />
            <motion.aside
              className="drawer"
              role="dialog"
              aria-modal="true"
              aria-label={dict.cart.title}
              initial={{ x: slideFrom }}
              animate={{ x: 0 }}
              exit={{ x: slideFrom }}
              transition={{ type: 'spring', damping: 32, stiffness: 320 }}
            >
              <div className="drawer__head">
                <h2>{dict.cart.title}</h2>
                <button type="button" className="icon-btn" onClick={close} aria-label={dict.common.close}>
                  <X />
                </button>
              </div>

              {done ? (
                <div className="drawer__body">
                  <div className="drawer__empty drawer__success">
                    <CircleCheck aria-hidden="true" />
                    <h3>{dict.cart.successTitle}</h3>
                    <p>{t(dict.cart.successText, { id: done.id })}</p>
                    <a href={done.wa} target="_blank" rel="noopener noreferrer" className="btn btn--wa">
                      <WhatsAppIcon />
                      {dict.cart.successWa}
                    </a>
                    <button type="button" className="btn btn--ghost btn--sm" onClick={closeAll}>
                      {dict.cart.continue}
                    </button>
                  </div>
                </div>
              ) : items.length === 0 ? (
                <div className="drawer__body">
                  <div className="drawer__empty">
                    <ShoppingBag aria-hidden="true" />
                    <p>{dict.cart.empty}</p>
                    <Link href={`/${locale}/serrures`} className="btn btn--primary" onClick={close}>
                      {dict.cart.emptyCta}
                    </Link>
                  </div>
                </div>
              ) : (
                <>
                  <div className="drawer__body">
                    {items.map((i) => (
                      <div className="cart-item" key={i.key}>
                        <div className="cart-item__media">
                          {i.image && <SmartImage src={i.image} alt={i.name[locale]} fill sizes="76px" />}
                        </div>
                        <div>
                          <Link href={`/${locale}/serrures/${i.slug}`} className="cart-item__name" onClick={close}>
                            {i.name[locale]}
                          </Link>
                          {i.variant && <div className="cart-item__variant">{i.variant.label[locale]}</div>}
                          <div className="cart-item__row">
                            <div className="qty">
                              <button type="button" onClick={() => setQty(i.key, i.qty - 1)} aria-label="-">
                                <Minus />
                              </button>
                              <span>{i.qty}</span>
                              <button type="button" onClick={() => setQty(i.key, i.qty + 1)} aria-label="+">
                                <Plus />
                              </button>
                            </div>
                            <strong>{formatPrice(i.price * i.qty, locale)}</strong>
                          </div>
                          <button type="button" className="cart-item__remove" onClick={() => remove(i.key)}>
                            {dict.cart.remove}
                          </button>
                        </div>
                      </div>
                    ))}

                    <div className="form-grid">
                      <div className="form-grid form-grid--2">
                        <div className="field">
                          <label htmlFor="cart-name">{dict.cart.name}</label>
                          <input
                            id="cart-name"
                            className="input"
                            value={name}
                            maxLength={80}
                            autoComplete="name"
                            onChange={(e) => setName(e.target.value)}
                          />
                        </div>
                        <div className="field">
                          <label htmlFor="cart-city">{dict.cart.city}</label>
                          <input
                            id="cart-city"
                            className="input"
                            value={city}
                            maxLength={60}
                            autoComplete="address-level2"
                            onChange={(e) => setCity(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="field">
                        <label htmlFor="cart-phone">{dict.cart.phone}</label>
                        <input
                          id="cart-phone"
                          className="input"
                          type="tel"
                          inputMode="tel"
                          dir="ltr"
                          placeholder="06 12 34 56 78"
                          value={phone}
                          maxLength={20}
                          autoComplete="tel"
                          required
                          onChange={(e) => setPhone(e.target.value)}
                        />
                      </div>
                      <div className="field">
                        <label htmlFor="cart-address">{dict.cart.address}</label>
                        <textarea
                          id="cart-address"
                          className="textarea"
                          style={{ minHeight: 80 }}
                          placeholder={dict.cart.addressPlaceholder}
                          value={address}
                          maxLength={300}
                          autoComplete="street-address"
                          required
                          onChange={(e) => setAddress(e.target.value)}
                        />
                      </div>
                      <div className="field">
                        <label htmlFor="cart-note">{dict.cart.note}</label>
                        <input id="cart-note" className="input" value={note} maxLength={500} onChange={(e) => setNote(e.target.value)} />
                      </div>
                    </div>
                  </div>

                  <div className="drawer__foot">
                    <div className="sumline">
                      <span>{dict.cart.subtotal}</span>
                      <span>{formatPrice(subtotal, locale)}</span>
                    </div>
                    <div className="sumline">
                      <span>{dict.cart.install}</span>
                      <span className="free">{dict.cart.installFree}</span>
                    </div>
                    <div className="sumline sumline--total">
                      <span>{dict.cart.total}</span>
                      <span>{formatPrice(subtotal, locale)}</span>
                    </div>
                    {error && <p className="form-error">{error}</p>}
                    <button type="button" className="btn btn--primary btn--block" onClick={checkout} disabled={sending}>
                      {sending ? <LoaderCircle className="spin" /> : <CircleCheck />}
                      {sending ? dict.cart.sending : dict.cart.checkout}
                    </button>
                    <button type="button" className="btn btn--ghost btn--block btn--sm" onClick={close}>
                      {dict.cart.continue}
                    </button>
                  </div>
                </>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div
            className="toast"
            role="status"
            initial={{ opacity: 0, y: 20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 20, x: '-50%' }}
          >
            <CircleCheck />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
