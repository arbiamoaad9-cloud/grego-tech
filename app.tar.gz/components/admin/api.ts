import type { Order, OrderStatus, Product } from '@/lib/types';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(url: string, init: RequestInit = {}): Promise<T> {
  const isForm = init.body instanceof FormData;
  const res = await fetch(url, {
    ...init,
    credentials: 'same-origin',
    headers: {
      ...(isForm ? {} : { 'Content-Type': 'application/json' }),
      'x-grego-request': '1',
      ...(init.headers || {}),
    },
  });
  if (res.status === 401) {
    window.location.assign('/admin/login');
    throw new ApiError('Session expirée', 401);
  }
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new ApiError(data.error || `Erreur ${res.status}`, res.status);
  return data;
}

export type ProductPayload = Omit<Product, 'id' | 'createdAt' | 'updatedAt'>;

export const adminApi = {
  list: () => request<{ products: Product[] }>('/api/admin/products'),
  create: (p: ProductPayload) => request<{ product: Product }>('/api/admin/products', { method: 'POST', body: JSON.stringify(p) }),
  update: (id: string, p: ProductPayload) =>
    request<{ product: Product }>(`/api/admin/products/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify(p) }),
  patch: (id: string, p: Partial<Pick<Product, 'visible' | 'featured' | 'stock'>>) =>
    request<{ product: Product }>(`/api/admin/products/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(p) }),
  remove: (id: string) => request<{ ok: true }>(`/api/admin/products/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  upload: (file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    return request<{ url: string }>('/api/admin/upload', { method: 'POST', body: fd });
  },
  orders: () => request<{ orders: Order[] }>('/api/admin/orders'),
  setOrderStatus: (id: string, status: OrderStatus) =>
    request<{ order: Order }>(`/api/admin/orders/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ status }) }),
  removeOrder: (id: string) => request<{ ok: true }>(`/api/admin/orders/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  logout: () => request<{ ok: true }>('/api/admin/logout', { method: 'POST' }),
};
