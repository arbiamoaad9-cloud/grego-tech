'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { ChevronDown, LoaderCircle, MapPin, Phone, RefreshCw, ShoppingCart, Trash2 } from 'lucide-react';
import { adminApi } from './api';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { formatPrice } from '@/lib/format';
import { ORDER_STATUSES, type Order, type OrderStatus } from '@/lib/types';

const STATUS_LABELS: Record<OrderStatus, string> = {
  new: 'Nouvelle',
  confirmed: 'Confirmée',
  delivered: 'Livrée / installée',
  cancelled: 'Annulée',
};

const STATUS_BADGE: Record<OrderStatus, string> = {
  new: 'badge--soft',
  confirmed: 'badge--amber',
  delivered: 'badge--green',
  cancelled: 'badge--sale',
};

type Filter = 'all' | OrderStatus;

function waLink(o: Order) {
  const intl = `212${o.customer.phone.replace(/^0/, '')}`;
  const msg =
    o.locale === 'ar'
      ? `السلام عليكم ${o.customer.name}، نتواصل معكم من Grego Tech بخصوص طلبكم رقم ${o.id}.`
      : `Bonjour ${o.customer.name}, Grego Tech vous contacte au sujet de votre commande ${o.id}.`;
  return `https://wa.me/${intl}?text=${encodeURIComponent(msg)}`;
}

export default function OrdersPanel({ notify }: { notify: (type: 'ok' | 'err', text: string) => void }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>('all');
  const [openId, setOpenId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setOrders((await adminApi.orders()).orders);
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Chargement impossible');
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    load();
  }, [load]);

  const stats = useMemo(() => {
    const active = orders.filter((o) => o.status !== 'cancelled');
    return {
      total: orders.length,
      fresh: orders.filter((o) => o.status === 'new').length,
      revenue: active.reduce((n, o) => n + o.total, 0),
      delivered: orders.filter((o) => o.status === 'delivered').length,
    };
  }, [orders]);

  const list = filter === 'all' ? orders : orders.filter((o) => o.status === filter);

  const setStatus = async (o: Order, status: OrderStatus) => {
    setBusy(o.id);
    try {
      const { order } = await adminApi.setOrderStatus(o.id, status);
      setOrders((prev) => prev.map((x) => (x.id === order.id ? order : x)));
      notify('ok', `Commande ${o.id} : ${STATUS_LABELS[status]}`);
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Mise à jour impossible');
    } finally {
      setBusy(null);
    }
  };

  const remove = async (o: Order) => {
    if (!window.confirm(`Supprimer définitivement la commande ${o.id} ?`)) return;
    setBusy(o.id);
    try {
      await adminApi.removeOrder(o.id);
      setOrders((prev) => prev.filter((x) => x.id !== o.id));
      notify('ok', 'Commande supprimée');
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Suppression impossible');
    } finally {
      setBusy(null);
    }
  };

  return (
    <>
      <section className="admin-stats">
        <div className="admin-stat">
          <ShoppingCart />
          <div>
            <strong>{stats.total}</strong>
            <span>Commandes reçues</span>
          </div>
        </div>
        <div className="admin-stat">
          <LoaderCircle />
          <div>
            <strong>{stats.fresh}</strong>
            <span>À traiter</span>
          </div>
        </div>
        <div className="admin-stat">
          <MapPin />
          <div>
            <strong>{stats.delivered}</strong>
            <span>Livrées / installées</span>
          </div>
        </div>
        <div className="admin-stat">
          <RefreshCw />
          <div>
            <strong>{formatPrice(stats.revenue, 'fr')}</strong>
            <span>Chiffre d&apos;affaires (hors annulées)</span>
          </div>
        </div>
      </section>

      <section className="admin-card">
        <div className="admin-toolbar">
          <h1>Commandes</h1>
          <div className="admin-tabs" role="tablist">
            {(['all', ...ORDER_STATUSES] as Filter[]).map((k) => (
              <button key={k} type="button" role="tab" aria-selected={filter === k} className={filter === k ? 'is-active' : ''} onClick={() => setFilter(k)}>
                {k === 'all' ? 'Toutes' : STATUS_LABELS[k]}
              </button>
            ))}
          </div>
          <button type="button" className="btn btn--outline btn--sm" onClick={load}>
            <RefreshCw />
            Actualiser
          </button>
        </div>

        {loading ? (
          <div className="admin-empty">
            <LoaderCircle className="spin" />
            Chargement…
          </div>
        ) : list.length === 0 ? (
          <div className="admin-empty">
            <ShoppingCart />
            Aucune commande pour le moment.
          </div>
        ) : (
          <div className="admin-orders">
            {list.map((o) => {
              const open = openId === o.id;
              const count = o.items.reduce((n, i) => n + i.qty, 0);
              return (
                <article key={o.id} className={`admin-order${open ? ' is-open' : ''}`}>
                  <button type="button" className="admin-order__head" onClick={() => setOpenId(open ? null : o.id)} aria-expanded={open}>
                    <span className="admin-order__id">{o.id}</span>
                    <span className="admin-order__who">
                      <strong>{o.customer.name}</strong>
                      <small>
                        {o.customer.city} · {new Date(o.createdAt).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}
                      </small>
                    </span>
                    <span className="admin-order__count">{count} article{count > 1 ? 's' : ''}</span>
                    <strong className="admin-order__total">{formatPrice(o.total, 'fr')}</strong>
                    <span className={`badge ${STATUS_BADGE[o.status]}`}>{STATUS_LABELS[o.status]}</span>
                    <ChevronDown className="admin-order__chev" />
                  </button>

                  {open && (
                    <div className="admin-order__body">
                      <div className="admin-order__grid">
                        <div>
                          <h3>Client</h3>
                          <p>
                            <strong>{o.customer.name}</strong>
                          </p>
                          <p>
                            <Phone /> <a href={`tel:${o.customer.phone}`}>{o.customer.phone}</a>
                          </p>
                          <p>
                            <MapPin /> {o.customer.address}, {o.customer.city}
                          </p>
                          {o.customer.note && <p className="admin-hint">Remarque : {o.customer.note}</p>}
                          <a href={waLink(o)} target="_blank" rel="noopener noreferrer" className="btn btn--wa btn--sm" style={{ marginTop: 10 }}>
                            <WhatsAppIcon />
                            Contacter sur WhatsApp
                          </a>
                        </div>
                        <div>
                          <h3>Articles</h3>
                          <ul className="admin-order__items">
                            {o.items.map((i, idx) => (
                              <li key={idx}>
                                <span>
                                  {i.qty} × {i.name}
                                  {i.variant ? ` (${i.variant})` : ''}
                                </span>
                                <strong>{formatPrice(i.unitPrice * i.qty, 'fr')}</strong>
                              </li>
                            ))}
                            <li className="is-total">
                              <span>Total (installation offerte)</span>
                              <strong>{formatPrice(o.total, 'fr')}</strong>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div className="admin-order__actions">
                        <span className="admin-hint">Changer le statut :</span>
                        {ORDER_STATUSES.map((s) => (
                          <button
                            key={s}
                            type="button"
                            className={`chip${o.status === s ? ' is-active' : ''}`}
                            disabled={busy === o.id}
                            onClick={() => o.status !== s && setStatus(o, s)}
                          >
                            {STATUS_LABELS[s]}
                          </button>
                        ))}
                        <button type="button" className="icon-btn is-danger" style={{ marginLeft: 'auto' }} onClick={() => remove(o)} title="Supprimer">
                          <Trash2 />
                        </button>
                      </div>
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </section>
    </>
  );
}
