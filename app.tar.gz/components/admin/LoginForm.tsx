'use client';

import { useState, type FormEvent } from 'react';
import { Eye, EyeOff, LoaderCircle, LockKeyhole } from 'lucide-react';
import { GregoMark } from '@/components/ui/Icons';

export default function LoginForm() {
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!password) return;
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
        credentials: 'same-origin',
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Connexion impossible');
      window.location.assign('/admin');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connexion impossible');
      setLoading(false);
    }
  };

  return (
    <main className="admin-login">
      <form className="admin-login__card" onSubmit={onSubmit}>
        <div className="admin-login__brand">
          <GregoMark className="logo__mark" />
          <div>
            <strong>Grego Tech</strong>
            <span>Espace administration</span>
          </div>
        </div>
        <div className="field">
          <label htmlFor="pw">Mot de passe</label>
          <div className="admin-pw">
            <LockKeyhole aria-hidden="true" />
            <input
              id="pw"
              className="input"
              type={show ? 'text' : 'password'}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              maxLength={200}
              autoFocus
              required
            />
            <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Masquer' : 'Afficher'}>
              {show ? <EyeOff /> : <Eye />}
            </button>
          </div>
        </div>
        {error && <p className="form-error">{error}</p>}
        <button type="submit" className="btn btn--primary btn--block" disabled={loading}>
          {loading ? <LoaderCircle className="spin" /> : null}
          Se connecter
        </button>
        <p className="admin-login__foot">Accès réservé à l&apos;équipe Grego SARL.</p>
      </form>
    </main>
  );
}
