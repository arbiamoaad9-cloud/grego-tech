'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Boxes,
  ExternalLink,
  Eye,
  EyeOff,
  LoaderCircle,
  LogOut,
  Package,
  Pencil,
  Plus,
  Search,
  ShoppingCart,
  Star,
  Tag,
  Trash2,
  TriangleAlert,
} from 'lucide-react';
import ProductEditor from './ProductEditor';
import OrdersPanel from './OrdersPanel';
import { adminApi, type ProductPayload } from './api';
import { GregoMark, MODE_ICONS } from '@/components/ui/Icons';
import { formatPrice, discountPercent } from '@/lib/format';
import type { Product } from '@/lib/types';

type Filter = 'all' | 'visible' | 'hidden' | 'low';

export default function AdminDashboard() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Product | null>(null);
  const [toast, setToast] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [view, setView] = useState<'orders' | 'products'>('orders');
  const [newOrders, setNewOrders] = useState(0);

  const notify = useCallback((type: 'ok' | 'err', text: string) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3000);
  }, []);

  const load = useCallback(async () => {
    try {
      const { products } = await adminApi.list();
      setProducts(products);
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Chargement impossible');
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    load();
    adminApi
      .orders()
      .then(({ orders }) => setNewOrders(orders.filter((o) => o.status === 'new').length))
      .catch(() => undefined);
  }, [load]);

  const stats = useMemo(() => {
    const visible = products.filter((p) => p.visible).length;
    const low = products.filter((p) => p.stock <= 3).length;
    const avg = products.length ? products.reduce((n, p) => n + p.price, 0) / products.length : 0;
    return { total: products.length, visible, low, avg };
  }, [products]);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (filter === 'visible' && !p.visible) return false;
      if (filter === 'hidden' && p.visible) return false;
      if (filter === 'low' && p.stock > 3) return false;
      if (q && !`${p.name.fr} ${p.name.ar} ${p.sku} ${p.slug}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [products, query, filter]);

  const quickPatch = async (p: Product, patch: Partial<Pick<Product, 'visible' | 'featured'>>) => {
    setBusyId(p.id);
    try {
      const { product } = await adminApi.patch(p.id, patch);
      setProducts((prev) => prev.map((x) => (x.id === product.id ? product : x)));
      notify('ok', 'Produit mis à jour');
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Échec de la mise à jour');
    } finally {
      setBusyId(null);
    }
  };

  const save = async (payload: ProductPayload, id?: string) => {
    if (id) {
      const { product } = await adminApi.update(id, payload);
      setProducts((prev) => prev.map((x) => (x.id === id ? product : x)));
      notify('ok', 'Modifications enregistrées');
    } else {
      const { product } = await adminApi.create(payload);
      setProducts((prev) => [product, ...prev]);
      notify('ok', 'Serrure ajoutée au catalogue');
    }
    setEditing(null);
  };

  const doDelete = async () => {
    if (!confirmDelete) return;
    const p = confirmDelete;
    setBusyId(p.id);
    try {
      await adminApi.remove(p.id);
      setProducts((prev) => prev.filter((x) => x.id !== p.id));
      notify('ok', 'Produit supprimé');
    } catch (e) {
      notify('err', e instanceof Error ? e.message : 'Suppression impossible');
    } finally {
      setBusyId(null);
      setConfirmDelete(null);
    }
  };

  const logout = async () => {
    await adminApi.logout().catch(() => undefined);
    window.location.assign('/admin/login');
  };

  return (
    <div className="admin">
      <header className="admin-top">
        <div className="admin-top__brand">
          <GregoMark className="logo__mark" />
          <div>
            <strong>Grego Tech</strong>
            <span>Tableau de bord</span>
          </div>
        </div>
        <div className="admin-switch-view" role="tablist">
          <button type="button" role="tab" aria-selected={view === 'orders'} className={view === 'orders' ? 'is-active' : ''} onClick={() => setView('orders')}>
            <ShoppingCart />
            Commandes
            {newOrders > 0 && <span className="pill">{newOrders}</span>}
          </button>
          <button type="button" role="tab" aria-selected={view === 'products'} className={view === 'products' ? 'is-active' : ''} onClick={() => setView('products')}>
            <Package />
            Produits
          </button>
        </div>
        <div className="admin-top__actions">
          <a href="/fr" target="_blank" rel="noopener noreferrer" className="btn btn--outline btn--sm">
            <ExternalLink />
            Voir le site
          </a>
          <button type="button" className="btn btn--ghost btn--sm" onClick={logout}>
            <LogOut />
            Déconnexion
          </button>
        </div>
      </header>

      <main className="admin-main">
        {view === 'orders' ? (
          <OrdersPanel notify={notify} />
        ) : (
        <>
        <section className="admin-stats">
          <div className="admin-stat">
            <Package />
            <div>
              <strong>{stats.total}</strong>
              <span>Serrures au catalogue</span>
            </div>
          </div>
          <div className="admin-stat">
            <Eye />
            <div>
              <strong>{stats.visible}</strong>
              <span>Visibles en boutique</span>
            </div>
          </div>
          <div className="admin-stat">
            <TriangleAlert />
            <div>
              <strong>{stats.low}</strong>
              <span>Stock faible (≤ 3)</span>
            </div>
          </div>
          <div className="admin-stat">
            <Tag />
            <div>
              <strong>{formatPrice(stats.avg, 'fr')}</strong>
              <span>Prix moyen</span>
            </div>
          </div>
        </section>

        <section className="admin-card">
          <div className="admin-toolbar">
            <h1>Catalogue produits</h1>
            <label className="search">
              <span className="sr-only">Rechercher</span>
              <Search aria-hidden="true" />
              <input className="input" type="search" placeholder="Rechercher…" value={query} onChange={(e) => setQuery(e.target.value)} />
            </label>
            <div className="admin-tabs" role="tablist">
              {(
                [
                  ['all', 'Tous'],
                  ['visible', 'Visibles'],
                  ['hidden', 'Masqués'],
                  ['low', 'Stock faible'],
                ] as [Filter, string][]
              ).map(([k, label]) => (
                <button key={k} type="button" role="tab" aria-selected={filter === k} className={filter === k ? 'is-active' : ''} onClick={() => setFilter(k)}>
                  {label}
                </button>
              ))}
            </div>
            <button type="button" className="btn btn--primary btn--sm" onClick={() => setEditing('new')}>
              <Plus />
              Ajouter une serrure
            </button>
          </div>

          {loading ? (
            <div className="admin-empty">
              <LoaderCircle className="spin" />
              Chargement…
            </div>
          ) : list.length === 0 ? (
            <div className="admin-empty">
              <Boxes />
              Aucun produit ne correspond.
            </div>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Produit</th>
                    <th>Prix</th>
                    <th>Stock</th>
                    <th>Modes</th>
                    <th>Statut</th>
                    <th aria-label="Actions" />
                  </tr>
                </thead>
                <tbody>
                  {list.map((p) => {
                    const off = discountPercent(p.price, p.compareAtPrice);
                    return (
                      <tr key={p.id} className={p.visible ? '' : 'is-hidden'}>
                        <td>
                          <div className="admin-prod">
                            <span className="admin-thumb">
                              {p.images[0] ? (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img src={p.images[0]} alt="" loading="lazy" />
                              ) : (
                                <Package />
                              )}
                            </span>
                            <div>
                              <strong>{p.name.fr}</strong>
                              <span dir="rtl">{p.name.ar}</span>
                            </div>
                          </div>
                        </td>
                        <td>
                          <strong>{formatPrice(p.price, 'fr')}</strong>
                          {off && (
                            <span className="admin-sub">
                              <s>{formatPrice(p.compareAtPrice!, 'fr')}</s> · -{off}%
                            </span>
                          )}
                        </td>
                        <td>
                          <span className={`admin-stock${p.stock <= 3 ? ' is-low' : ''}`}>{p.stock}</span>
                        </td>
                        <td>
                          <div className="admin-modes">
                            {p.modes.map((m) => {
                              const Icon = MODE_ICONS[m];
                              return <Icon key={m} aria-label={m} />;
                            })}
                          </div>
                        </td>
                        <td>
                          <span className={`badge ${p.visible ? 'badge--green' : 'badge--amber'}`}>{p.visible ? 'En ligne' : 'Masqué'}</span>
                          {p.featured && <span className="badge badge--soft" style={{ marginInlineStart: 6 }}>Vedette</span>}
                        </td>
                        <td>
                          <div className="admin-actions">
                            <button
                              type="button"
                              className="icon-btn"
                              title={p.featured ? 'Retirer des vedettes' : 'Mettre en vedette'}
                              disabled={busyId === p.id}
                              onClick={() => quickPatch(p, { featured: !p.featured })}
                            >
                              <Star fill={p.featured ? 'currentColor' : 'none'} />
                            </button>
                            <button
                              type="button"
                              className="icon-btn"
                              title={p.visible ? 'Masquer' : 'Afficher'}
                              disabled={busyId === p.id}
                              onClick={() => quickPatch(p, { visible: !p.visible })}
                            >
                              {p.visible ? <EyeOff /> : <Eye />}
                            </button>
                            <button type="button" className="icon-btn" title="Modifier" onClick={() => setEditing(p)}>
                              <Pencil />
                            </button>
                            <button type="button" className="icon-btn is-danger" title="Supprimer" onClick={() => setConfirmDelete(p)}>
                              <Trash2 />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
        </>
        )}
      </main>

      <AnimatePresence>
        {editing && (
          <ProductEditor
            key={editing === 'new' ? 'new' : editing.id}
            product={editing === 'new' ? null : editing}
            onClose={() => setEditing(null)}
            onSave={save}
            onError={(msg) => notify('err', msg)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {confirmDelete && (
          <motion.div className="backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setConfirmDelete(null)}>
            <motion.div
              className="admin-confirm"
              role="alertdialog"
              aria-modal="true"
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              onClick={(e) => e.stopPropagation()}
            >
              <span className="admin-confirm__icon">
                <Trash2 />
              </span>
              <h2>Supprimer ce produit ?</h2>
              <p>
                « {confirmDelete.name.fr} » sera retiré définitivement du catalogue. Pour le retirer temporairement, préférez
                « Masquer ».
              </p>
              <div className="admin-confirm__actions">
                <button type="button" className="btn btn--outline btn--sm" onClick={() => setConfirmDelete(null)}>
                  Annuler
                </button>
                <button type="button" className="btn btn--sm admin-danger" onClick={doDelete} disabled={busyId === confirmDelete.id}>
                  Supprimer
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div
            className={`toast admin-toast is-${toast.type}`}
            role="status"
            initial={{ opacity: 0, y: 20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 20, x: '-50%' }}
          >
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
