'use client';

import { useRef, useState, type FormEvent } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, ArrowUp, ImagePlus, LoaderCircle, Plus, Save, Trash2, Upload, X } from 'lucide-react';
import { adminApi, type ProductPayload } from './api';
import { MODE_ICONS } from '@/components/ui/Icons';
import { COLLECTIONS, UNLOCK_MODES, type Collection, type Product, type UnlockMode } from '@/lib/types';

const MODE_LABELS: Record<UnlockMode, string> = {
  fingerprint: 'Empreinte',
  face: 'Visage 3D',
  palm: 'Paume',
  code: 'Code',
  card: 'Badge IC',
  app: 'App mobile',
  key: 'Clé',
};

const COLLECTION_LABELS: Record<Collection, string> = {
  'face-3d': 'Reconnaissance faciale 3D',
  handle: 'Poignées biométriques',
  apartment: "Serrures d'appartement",
  waterproof: 'Waterproof',
};

type Tab = 'general' | 'fr' | 'ar' | 'media' | 'variants';

interface FormState {
  slug: string;
  sku: string;
  nameFr: string;
  nameAr: string;
  shortFr: string;
  shortAr: string;
  descFr: string;
  descAr: string;
  featFr: string;
  featAr: string;
  price: string;
  compareAt: string;
  stock: string;
  images: string[];
  modes: UnlockMode[];
  collections: Collection[];
  variants: { id?: string; fr: string; ar: string; price: string }[];
  visible: boolean;
  featured: boolean;
}

function toForm(p: Product | null): FormState {
  return {
    slug: p?.slug ?? '',
    sku: p?.sku ?? '',
    nameFr: p?.name.fr ?? '',
    nameAr: p?.name.ar ?? '',
    shortFr: p?.shortDescription.fr ?? '',
    shortAr: p?.shortDescription.ar ?? '',
    descFr: p?.description.fr ?? '',
    descAr: p?.description.ar ?? '',
    featFr: p?.features.fr.join('\n') ?? '',
    featAr: p?.features.ar.join('\n') ?? '',
    price: p ? String(p.price) : '',
    compareAt: p?.compareAtPrice ? String(p.compareAtPrice) : '',
    stock: p ? String(p.stock) : '10',
    images: p?.images ?? [],
    modes: p?.modes ?? ['fingerprint', 'code', 'card', 'key'],
    collections: p?.collections ?? [],
    variants: p?.variants.map((v) => ({ id: v.id, fr: v.label.fr, ar: v.label.ar, price: v.price === null ? '' : String(v.price) })) ?? [],
    visible: p?.visible ?? true,
    featured: p?.featured ?? false,
  };
}

function toPayload(f: FormState): ProductPayload {
  const lines = (s: string) =>
    s
      .split('\n')
      .map((x) => x.trim())
      .filter(Boolean);
  return {
    slug: f.slug,
    sku: f.sku,
    name: { fr: f.nameFr, ar: f.nameAr },
    shortDescription: { fr: f.shortFr, ar: f.shortAr },
    description: { fr: f.descFr, ar: f.descAr },
    price: Number(f.price) || 0,
    compareAtPrice: f.compareAt ? Number(f.compareAt) : null,
    images: f.images,
    modes: f.modes,
    collections: f.collections,
    features: { fr: lines(f.featFr), ar: lines(f.featAr) },
    variants: f.variants
      .filter((v) => v.fr.trim())
      .map((v) => ({ id: v.id ?? '', label: { fr: v.fr, ar: v.ar }, price: v.price ? Number(v.price) : null })),
    stock: Math.max(0, Math.floor(Number(f.stock) || 0)),
    visible: f.visible,
    featured: f.featured,
  };
}

const IMAGE_URL = /^https:\/\/(cdn\.shopify\.com|(www\.)?sbk-quincaillerie\.com)\//i;

export default function ProductEditor({
  product,
  onClose,
  onSave,
  onError,
}: {
  product: Product | null;
  onClose: () => void;
  onSave: (payload: ProductPayload, id?: string) => Promise<void>;
  onError: (msg: string) => void;
}) {
  const [tab, setTab] = useState<Tab>('general');
  const [f, setF] = useState<FormState>(() => toForm(product));
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [errors, setErrors] = useState<string[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }));
  const toggle = <T extends string>(list: T[], v: T): T[] => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);

  const validate = (): string[] => {
    const e: string[] = [];
    if (f.nameFr.trim().length < 2) e.push('Le nom (FR) est obligatoire.');
    if (!(Number(f.price) > 0)) e.push('Le prix doit être supérieur à 0.');
    if (f.compareAt && Number(f.compareAt) <= Number(f.price)) e.push("L'ancien prix doit être supérieur au prix de vente.");
    if (!f.modes.length) e.push("Sélectionnez au moins un mode d'ouverture.");
    if (!f.images.length) e.push('Ajoutez au moins une image.');
    return e;
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (errs.length) return;
    setSaving(true);
    try {
      await onSave(toPayload(f), product?.id);
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Enregistrement impossible');
      setSaving(false);
    }
  };

  const addUrl = () => {
    const u = imageUrl.trim();
    if (!IMAGE_URL.test(u)) {
      onError('URL non autorisée : utilisez cdn.shopify.com ou sbk-quincaillerie.com, ou importez un fichier.');
      return;
    }
    set('images', [...f.images, u].slice(0, 12));
    setImageUrl('');
  };

  const [drag, setDrag] = useState(false);
  const upload = async (files: FileList | File[] | null | undefined) => {
    const list = Array.from(files || []).filter((f) => f.type.startsWith('image/'));
    if (!list.length) return;
    setUploading(true);
    try {
      for (const file of list) {
        const { url } = await adminApi.upload(file);
        setF((s) => ({ ...s, images: [...s.images, url].slice(0, 12) }));
      }
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Import impossible');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const move = (i: number, d: number) => {
    const next = [...f.images];
    const j = i + d;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    set('images', next);
  };

  const TABS: [Tab, string][] = [
    ['general', 'Général'],
    ['fr', 'Français'],
    ['ar', 'العربية'],
    ['media', `Images (${f.images.length})`],
    ['variants', `Variantes (${f.variants.length})`],
  ];

  return (
    <motion.div className="backdrop admin-editor-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.form
        className="admin-editor"
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 32, stiffness: 300 }}
        aria-label={product ? 'Modifier le produit' : 'Nouveau produit'}
      >
        <div className="admin-editor__head">
          <div>
            <span className="admin-sub">{product ? 'Modifier' : 'Nouvelle serrure'}</span>
            <h2>{f.nameFr || 'Sans titre'}</h2>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Fermer">
            <X />
          </button>
        </div>

        <div className="admin-tabs admin-tabs--editor" role="tablist">
          {TABS.map(([k, label]) => (
            <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? 'is-active' : ''} onClick={() => setTab(k)}>
              {label}
            </button>
          ))}
        </div>

        <div className="admin-editor__body">
          {tab === 'general' && (
            <div className="form-grid">
              <div className="form-grid form-grid--3">
                <div className="field">
                  <label htmlFor="ed-price">Prix (DH) *</label>
                  <input id="ed-price" className="input" type="number" min={0} step={1} value={f.price} onChange={(e) => set('price', e.target.value)} />
                </div>
                <div className="field">
                  <label htmlFor="ed-compare">Ancien prix (DH)</label>
                  <input id="ed-compare" className="input" type="number" min={0} step={1} value={f.compareAt} onChange={(e) => set('compareAt', e.target.value)} />
                </div>
                <div className="field">
                  <label htmlFor="ed-stock">Stock</label>
                  <input id="ed-stock" className="input" type="number" min={0} step={1} value={f.stock} onChange={(e) => set('stock', e.target.value)} />
                </div>
              </div>
              {Number(f.compareAt) > Number(f.price) && Number(f.price) > 0 && (
                <p className="admin-hint">
                  Remise affichée : <strong>-{Math.round(((Number(f.compareAt) - Number(f.price)) / Number(f.compareAt)) * 100)}%</strong>
                </p>
              )}
              <div className="form-grid form-grid--2">
                <div className="field">
                  <label htmlFor="ed-sku">Référence (SKU)</label>
                  <input id="ed-sku" className="input" value={f.sku} maxLength={80} onChange={(e) => set('sku', e.target.value)} />
                </div>
                <div className="field">
                  <label htmlFor="ed-slug">Adresse URL (slug)</label>
                  <input id="ed-slug" className="input" value={f.slug} maxLength={80} placeholder="généré depuis le nom" onChange={(e) => set('slug', e.target.value)} />
                </div>
              </div>

              <fieldset className="admin-fieldset">
                <legend>Modes d&apos;ouverture *</legend>
                <div className="filters__chips">
                  {UNLOCK_MODES.map((m) => {
                    const Icon = MODE_ICONS[m];
                    const on = f.modes.includes(m);
                    return (
                      <button key={m} type="button" className={`chip${on ? ' is-active' : ''}`} aria-pressed={on} onClick={() => set('modes', toggle(f.modes, m))}>
                        <Icon />
                        {MODE_LABELS[m]}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <fieldset className="admin-fieldset">
                <legend>Collections</legend>
                <div className="filters__chips">
                  {COLLECTIONS.map((c) => {
                    const on = f.collections.includes(c);
                    return (
                      <button key={c} type="button" className={`chip${on ? ' is-active' : ''}`} aria-pressed={on} onClick={() => set('collections', toggle(f.collections, c))}>
                        {COLLECTION_LABELS[c]}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <div className="admin-switches">
                <label className="admin-switch">
                  <input type="checkbox" checked={f.visible} onChange={(e) => set('visible', e.target.checked)} />
                  <span />
                  Visible en boutique
                </label>
                <label className="admin-switch">
                  <input type="checkbox" checked={f.featured} onChange={(e) => set('featured', e.target.checked)} />
                  <span />
                  Mettre en avant sur l&apos;accueil
                </label>
              </div>
            </div>
          )}

          {(tab === 'fr' || tab === 'ar') && (
            <div className="form-grid" dir={tab === 'ar' ? 'rtl' : 'ltr'}>
              <div className="field">
                <label htmlFor={`ed-name-${tab}`}>{tab === 'fr' ? 'Nom du produit *' : 'اسم المنتج'}</label>
                <input
                  id={`ed-name-${tab}`}
                  className="input"
                  maxLength={120}
                  value={tab === 'fr' ? f.nameFr : f.nameAr}
                  onChange={(e) => set(tab === 'fr' ? 'nameFr' : 'nameAr', e.target.value)}
                />
              </div>
              <div className="field">
                <label htmlFor={`ed-short-${tab}`}>{tab === 'fr' ? 'Description courte' : 'وصف قصير'}</label>
                <textarea
                  id={`ed-short-${tab}`}
                  className="textarea"
                  style={{ minHeight: 80 }}
                  maxLength={300}
                  value={tab === 'fr' ? f.shortFr : f.shortAr}
                  onChange={(e) => set(tab === 'fr' ? 'shortFr' : 'shortAr', e.target.value)}
                />
              </div>
              <div className="field">
                <label htmlFor={`ed-feat-${tab}`}>{tab === 'fr' ? 'Points forts (un par ligne)' : 'المميزات (سطر لكل ميزة)'}</label>
                <textarea
                  id={`ed-feat-${tab}`}
                  className="textarea"
                  value={tab === 'fr' ? f.featFr : f.featAr}
                  onChange={(e) => set(tab === 'fr' ? 'featFr' : 'featAr', e.target.value)}
                />
              </div>
              <div className="field">
                <label htmlFor={`ed-desc-${tab}`}>
                  {tab === 'fr' ? 'Description détaillée (HTML simple : p, h2, h3, ul, li, strong)' : 'الوصف المفصل'}
                </label>
                <textarea
                  id={`ed-desc-${tab}`}
                  className="textarea admin-code"
                  style={{ minHeight: 260 }}
                  value={tab === 'fr' ? f.descFr : f.descAr}
                  onChange={(e) => set(tab === 'fr' ? 'descFr' : 'descAr', e.target.value)}
                />
              </div>
            </div>
          )}

          {tab === 'media' && (
            <div className="form-grid">
              <div
                className={`admin-drop${drag ? ' is-drag' : ''}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDrag(true);
                }}
                onDragLeave={() => setDrag(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDrag(false);
                  upload(e.dataTransfer.files);
                }}
                onClick={() => fileRef.current?.click()}
                role="button"
                tabIndex={0}
              >
                {uploading ? <LoaderCircle className="spin" /> : <Upload />}
                <strong>{uploading ? 'Import en cours…' : 'Glissez vos photos ici ou cliquez pour les choisir'}</strong>
                <small>JPG, PNG, WEBP — plusieurs photos possibles. Elles sont optimisées et mises en ligne automatiquement.</small>
              </div>
              <div className="admin-images">
                {f.images.map((src, i) => (
                  <div className="admin-image" key={`${src}-${i}`}>
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={src} alt="" />
                    {i === 0 && <span className="badge badge--soft admin-image__main">Principale</span>}
                    <div className="admin-image__tools">
                      <button type="button" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Monter">
                        <ArrowUp />
                      </button>
                      <button type="button" onClick={() => move(i, 1)} disabled={i === f.images.length - 1} aria-label="Descendre">
                        <ArrowDown />
                      </button>
                      <button type="button" onClick={() => set('images', f.images.filter((_, j) => j !== i))} aria-label="Retirer">
                        <Trash2 />
                      </button>
                    </div>
                  </div>
                ))}
                <button type="button" className="admin-image admin-image--add" onClick={() => fileRef.current?.click()} disabled={uploading}>
                  {uploading ? <LoaderCircle className="spin" /> : <Upload />}
                  Importer
                </button>
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple hidden onChange={(e) => upload(e.target.files)} />
              </div>
              <div className="field">
                <label htmlFor="ed-url">Ou ajouter une image par lien (CDN Shopify / SBK)</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input
                    id="ed-url"
                    className="input"
                    placeholder="https://cdn.shopify.com/…"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addUrl();
                      }
                    }}
                  />
                  <button type="button" className="btn btn--outline btn--sm" onClick={addUrl} style={{ height: 48 }}>
                    <ImagePlus />
                    Ajouter
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === 'variants' && (
            <div className="form-grid">
              <p className="admin-hint">Finitions ou options (ex. Noir mat, Gris, Doré). Laissez le prix vide pour utiliser le prix du produit.</p>
              {f.variants.map((v, i) => (
                <div className="admin-variant" key={i}>
                  <input
                    className="input"
                    placeholder="Libellé FR"
                    value={v.fr}
                    maxLength={60}
                    onChange={(e) => set('variants', f.variants.map((x, j) => (j === i ? { ...x, fr: e.target.value } : x)))}
                  />
                  <input
                    className="input"
                    dir="rtl"
                    placeholder="التسمية"
                    value={v.ar}
                    maxLength={60}
                    onChange={(e) => set('variants', f.variants.map((x, j) => (j === i ? { ...x, ar: e.target.value } : x)))}
                  />
                  <input
                    className="input"
                    type="number"
                    min={0}
                    placeholder="Prix DH"
                    value={v.price}
                    onChange={(e) => set('variants', f.variants.map((x, j) => (j === i ? { ...x, price: e.target.value } : x)))}
                  />
                  <button type="button" className="icon-btn is-danger" onClick={() => set('variants', f.variants.filter((_, j) => j !== i))} aria-label="Supprimer la variante">
                    <Trash2 />
                  </button>
                </div>
              ))}
              <button
                type="button"
                className="btn btn--outline btn--sm"
                style={{ justifySelf: 'start' }}
                onClick={() => set('variants', [...f.variants, { fr: '', ar: '', price: '' }].slice(0, 10))}
              >
                <Plus />
                Ajouter une variante
              </button>
            </div>
          )}
        </div>

        <div className="admin-editor__foot">
          {errors.length > 0 && (
            <ul className="admin-errors">
              {errors.map((e) => (
                <li key={e}>{e}</li>
              ))}
            </ul>
          )}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn--outline btn--sm" onClick={onClose}>
              Annuler
            </button>
            <button type="submit" className="btn btn--primary btn--sm" disabled={saving}>
              {saving ? <LoaderCircle className="spin" /> : <Save />}
              Enregistrer
            </button>
          </div>
        </div>
      </motion.form>
    </motion.div>
  );
}
