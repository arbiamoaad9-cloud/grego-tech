import { Headset, KeyRound, ShieldCheck, Smartphone } from 'lucide-react';
import Reveal from '@/components/ui/Reveal';
import type { Dictionary } from '@/lib/i18n';

const ICONS = [KeyRound, Smartphone, Headset, ShieldCheck];

export default function Guarantees({ dict }: { dict: Dictionary }) {
  return (
    <section className="guarantees" aria-label="Garanties">
      <div className="container">
        <Reveal className="guarantees__grid">
          {dict.guarantees.map((g, i) => {
            const Icon = ICONS[i];
            return (
              <div className="guarantee" key={g.title}>
                <span className="guarantee__icon">
                  <Icon aria-hidden="true" />
                </span>
                <div>
                  <h3>{g.title}</h3>
                  <p>{g.desc}</p>
                </div>
              </div>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
