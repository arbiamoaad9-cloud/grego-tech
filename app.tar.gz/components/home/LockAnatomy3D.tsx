'use client';

import { useRef, useState, type ReactNode } from 'react';
import {
  motion,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useSpring,
  useTransform,
  type MotionValue,
} from 'framer-motion';
import { Fingerprint, ScanFace } from 'lucide-react';
import { useLocale } from '@/components/i18n/LocaleProvider';

const LAYER_CLASSES = ['layer--outer', 'layer--bio', 'layer--cyl', 'layer--inner'];
const LAYER_TAGS = ['01 · OUTER', '02 · BIO', '03 · CYLINDER', '04 · INNER'];

function Layer({
  index,
  spread,
  active,
  children,
}: {
  index: number;
  spread: MotionValue<number>;
  active: boolean;
  children: ReactNode;
}) {
  const offset = index - 1.5;
  const z = useTransform(spread, (v) => -offset * v * 120);
  const x = useTransform(spread, (v) => offset * v * 70);
  const y = useTransform(spread, (v) => offset * v * -10);
  return (
    <motion.div
      className={`layer ${LAYER_CLASSES[index]}${active ? ' is-active' : ''}`}
      style={{ z, x, y, zIndex: 4 - index }}
    >
      <span className="layer__label" dir="ltr">
        {LAYER_TAGS[index]}
      </span>
      {children}
    </motion.div>
  );
}

export default function LockAnatomy3D() {
  const { dict } = useLocale();
  const a = dict.anatomy;
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const [step, setStep] = useState(0);

  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] });
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 22, mass: 0.4 });

  const spread = useTransform(progress, [0, 0.22, 0.85, 1], reduce ? [1, 1, 1, 1] : [0.05, 1, 1, 0.75]);
  const rotateY = useTransform(progress, [0, 1], reduce ? [-28, -28] : [-48, 24]);
  const rotateX = useTransform(progress, [0, 0.5, 1], [16, 10, 14]);
  const scale = useTransform(progress, [0, 0.2], [0.9, 1]);

  useMotionValueEvent(scrollYProgress, 'change', (v) => {
    setStep(Math.min(3, Math.max(0, Math.floor(v * 4.2))));
  });

  return (
    <section className="anatomy" ref={ref} aria-labelledby="anatomy-title">
      <div className="anatomy__sticky">
        <div className="container anatomy__grid">
          <div className="anatomy__copy">
            <span className="eyebrow">{a.eyebrow}</span>
            <h2 id="anatomy-title" className="title">
              {a.title}
            </h2>
            <p className="lead">{a.subtitle}</p>
            <ol className="anatomy__steps" style={{ listStyle: 'none', padding: 0 }}>
              {a.layers.map((l, i) => (
                <li key={l.title} className={`step${step === i ? ' is-active' : ''}`}>
                  <span className="step__num">{i + 1}</span>
                  <div>
                    <h3>{l.title}</h3>
                    <p>{l.desc}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>

          <div className="scene" aria-hidden="true">
            <div className="scene__shadow" />
            <motion.div className="scene__rig" style={{ rotateY, rotateX, scale }}>
              <Layer index={0} spread={spread} active={step === 0}>
                <div className="layer__keys">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <span key={i} />
                  ))}
                </div>
              </Layer>
              <Layer index={1} spread={spread} active={step === 1}>
                <ScanFace />
                <div className="layer__chip" />
                <Fingerprint />
              </Layer>
              <Layer index={2} spread={spread} active={step === 2}>
                <div className="layer__cylinder" />
              </Layer>
              <Layer index={3} spread={spread} active={step === 3}>
                <div className="layer__battery">
                  <span />
                  <span />
                  <span />
                  <span />
                </div>
              </Layer>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
