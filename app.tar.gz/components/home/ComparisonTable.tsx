import { Check, X } from 'lucide-react';
import Reveal from '@/components/ui/Reveal';
import type { Dictionary } from '@/lib/i18n';

function Mark({ ok, positive }: { ok: boolean; positive: boolean }) {
  // "positive" : la ligne décrit un avantage (true = bien) ou un risque (true = mal)
  const good = positive ? ok : !ok;
  return good ? (
    <span className="yes" aria-label={ok ? 'Oui' : 'Non'}>
      <Check strokeWidth={3} />
    </span>
  ) : (
    <span className="no" aria-label={ok ? 'Oui' : 'Non'}>
      <X strokeWidth={3} />
    </span>
  );
}

export default function ComparisonTable({ dict }: { dict: Dictionary }) {
  const c = dict.comparison;
  return (
    <section className="section section--tint">
      <div className="container">
        <Reveal className="section__head section__head--center">
          <span className="eyebrow">{c.eyebrow}</span>
          <h2 className="title">{c.title}</h2>
          <p className="lead">{c.subtitle}</p>
        </Reveal>
        <Reveal className="compare">
          <table>
            <thead>
              <tr>
                <th scope="col">
                  <span className="sr-only">—</span>
                </th>
                <th scope="col" className="is-us">
                  {c.us}
                </th>
                <th scope="col">{c.them}</th>
              </tr>
            </thead>
            <tbody>
              {c.rows.map((r) => {
                // La ligne "risque" est celle où la solution classique l'emporte sur le critère
                const positive = !(r.us === false && r.them === true);
                return (
                  <tr key={r.label}>
                    <td>{r.label}</td>
                    <td className="is-us">
                      <Mark ok={r.us} positive={positive} />
                    </td>
                    <td>
                      <Mark ok={r.them} positive={positive} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Reveal>
      </div>
    </section>
  );
}
