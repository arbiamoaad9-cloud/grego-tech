'use client';

import { useState, type FormEvent } from 'react';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { cleanPhone, cleanText } from '@/lib/sanitize';
import { whatsappUrl } from '@/lib/site';

export default function ContactForm() {
  const { dict } = useLocale();
  const c = dict.contact;
  const [form, setForm] = useState({ name: '', phone: '', subject: c.subjects[0], message: '' });
  const [error, setError] = useState('');
  // Champ piège invisible contre les robots
  const [trap, setTrap] = useState('');

  const update = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (trap) return;
    const name = cleanText(form.name, 80);
    const message = cleanText(form.message, 1000);
    if (!name || !message) {
      setError(c.required);
      return;
    }
    setError('');
    const text = [
      c.waIntro,
      `${c.name} : ${name}`,
      form.phone ? `${c.phone} : ${cleanPhone(form.phone)}` : '',
      `${c.subject} : ${cleanText(form.subject, 80)}`,
      '',
      message,
    ]
      .filter((l, i, arr) => l !== '' || arr[i - 1] !== '')
      .join('\n');
    window.open(whatsappUrl(text), '_blank', 'noopener,noreferrer');
  };

  return (
    <form className="panel form-grid" onSubmit={onSubmit} noValidate>
      <div className="form-grid form-grid--2">
        <div className="field">
          <label htmlFor="ct-name">{c.name}</label>
          <input id="ct-name" className="input" value={form.name} onChange={update('name')} maxLength={80} autoComplete="name" required />
        </div>
        <div className="field">
          <label htmlFor="ct-phone">{c.phone}</label>
          <input
            id="ct-phone"
            className="input"
            type="tel"
            dir="ltr"
            value={form.phone}
            onChange={update('phone')}
            maxLength={20}
            autoComplete="tel"
          />
        </div>
      </div>
      <div className="field">
        <label htmlFor="ct-subject">{c.subject}</label>
        <select id="ct-subject" className="select" value={form.subject} onChange={update('subject')}>
          {c.subjects.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>
      <div className="field">
        <label htmlFor="ct-message">{c.message}</label>
        <textarea id="ct-message" className="textarea" value={form.message} onChange={update('message')} maxLength={1000} required />
      </div>
      <input
        type="text"
        name="website"
        tabIndex={-1}
        autoComplete="off"
        value={trap}
        onChange={(e) => setTrap(e.target.value)}
        style={{ position: 'absolute', left: '-9999px', width: 1, height: 1, opacity: 0 }}
        aria-hidden="true"
      />
      {error && <p className="form-error">{error}</p>}
      <button type="submit" className="btn btn--wa btn--block">
        <WhatsAppIcon />
        {c.send}
      </button>
    </form>
  );
}
