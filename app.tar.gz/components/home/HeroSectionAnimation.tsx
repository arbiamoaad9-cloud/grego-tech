'use client';

import { useEffect, useState, type PointerEvent } from 'react';
import { AnimatePresence, motion, useMotionValue, useReducedMotion, useSpring } from 'framer-motion';
import { Fingerprint, Keyboard, KeyRound, ScanFace, type LucideIcon } from 'lucide-react';
import { useLocale } from '@/components/i18n/LocaleProvider';

type HotspotId = 'face' | 'keypad' | 'fingerprint' | 'backup';

const HOTSPOTS: { id: HotspotId; icon: LucideIcon; x: string; y: string; cardTop: number }[] = [
  { id: 'fingerprint', icon: Fingerprint, x: '78%', y: '70%', cardTop: 250 },
  { id: 'face', icon: ScanFace, x: '84%', y: '15%', cardTop: 0 },
  { id: 'keypad', icon: Keyboard, x: '86%', y: '44%', cardTop: 130 },
  { id: 'backup', icon: KeyRound, x: '72%', y: '92%', cardTop: 320 },
];

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'];

export default function HeroSectionAnimation() {
  const { locale, dict } = useLocale();
  const reduce = useReducedMotion();
  const [active, setActive] = useState<HotspotId | null>(null);
  const [interacted, setInteracted] = useState(false);

  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const rotateX = useSpring(rx, { stiffness: 120, damping: 18 });
  const rotateY = useSpring(ry, { stiffness: 120, damping: 18 });

  // Démonstration automatique tant que le visiteur n'a pas interagi
  useEffect(() => {
    if (interacted) return;
    let i = 0;
    const first = setTimeout(() => setActive(HOTSPOTS[0].id), 900);
    const loop = setInterval(() => {
      i = (i + 1) % HOTSPOTS.length;
      setActive(HOTSPOTS[i].id);
    }, 3400);
    return () => {
      clearTimeout(first);
      clearInterval(loop);
    };
  }, [interacted]);

  const onPointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (reduce || e.pointerType !== 'mouse') return;
    const r = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    ry.set(px * 16);
    rx.set(-py * 12);
  };

  const select = (id: HotspotId) => {
    setInteracted(true);
    setActive(id);
  };

  const current = HOTSPOTS.find((h) => h.id === active);
  const copy = active ? dict.hero.hotspots[active] : null;

  return (
    <>
      <div
        className="lockstage"
        dir="ltr"
        onPointerMove={onPointerMove}
        onPointerLeave={() => {
          rx.set(0);
          ry.set(0);
        }}
      >
        <motion.div
          className="lockstage__halo"
          aria-hidden="true"
          animate={reduce ? undefined : { scale: [1, 1.08, 1], opacity: [0.85, 1, 0.85] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="lockstage__ring"
          aria-hidden="true"
          animate={reduce ? undefined : { rotate: 360 }}
          transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
        />
        <div className="lockstage__ring lockstage__ring--2" aria-hidden="true" />

        <motion.div style={{ rotateX, rotateY, transformPerspective: 1000 }}>
          <div className="lockstage__scale">
            <motion.div
              className="lockstage__float"
              initial={reduce ? false : { opacity: 0, y: 40, scale: 0.94 }}
              animate={
                reduce
                  ? { opacity: 1 }
                  : { opacity: 1, scale: 1, y: [0, -14, 0], transition: { y: { duration: 6, repeat: Infinity, ease: 'easeInOut' }, opacity: { duration: 0.8 }, scale: { duration: 0.8 } } }
              }
            >
              <div className="lock" data-active={active ?? undefined} role="img" aria-label="Grego Tech smart lock">
                <div className="lock__camera">
                  <div className="lock__lens">
                    <span />
                    <span />
                    <span />
                  </div>
                  <div className="lock__facegrid" />
                  <div className="lock__laser" />
                </div>

                <div className="lock__keypad" aria-hidden="true">
                  {KEYS.map((k) => (
                    <span key={k} className="lock__key">
                      {k}
                    </span>
                  ))}
                </div>

                <div className="lock__finger" aria-hidden="true">
                  <Fingerprint strokeWidth={1.4} />
                </div>
                <span className="lock__status">{active === 'fingerprint' ? 'UNLOCKED' : 'GREGO'}</span>

                <div className="lock__bottom" aria-hidden="true">
                  <span className="lock__usb" />
                  <span className="lock__keyhole" />
                </div>

                {HOTSPOTS.map((h) => (
                  <button
                    key={h.id}
                    type="button"
                    className={`hotspot${active === h.id ? ' is-active' : ''}`}
                    style={{ left: h.x, top: h.y }}
                    onMouseEnter={() => select(h.id)}
                    onFocus={() => select(h.id)}
                    onClick={() => select(h.id)}
                    aria-label={dict.hero.hotspots[h.id].title}
                    aria-pressed={active === h.id}
                  >
                    <span className="hotspot__dot" />
                  </button>
                ))}
              </div>
              <div className="lock__handle" aria-hidden="true" />

              <AnimatePresence mode="wait">
                {current && copy && (
                  <motion.div
                    key={current.id}
                    className="hs-card glass"
                    style={{ top: current.cardTop }}
                    dir={locale === 'ar' ? 'rtl' : 'ltr'}
                    initial={{ opacity: 0, x: -12, scale: 0.96 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, x: 12, scale: 0.96 }}
                    transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
                    aria-live="polite"
                  >
                    <span className="hs-card__tag">
                      <current.icon aria-hidden="true" />
                      {copy.tag}
                    </span>
                    <h3>{copy.title}</h3>
                    <p>{copy.desc}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>
        </motion.div>
      </div>
      <p className="hero__hint">
        <Fingerprint aria-hidden="true" />
        {dict.hero.hint}
      </p>
    </>
  );
}
