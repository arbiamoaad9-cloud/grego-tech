'use client';

import dynamic from 'next/dynamic';

/** Chargement différé de l'animation (hors bundle initial, rendu client uniquement). */
const HeroSectionAnimation = dynamic(() => import('./HeroSectionAnimation'), {
  ssr: false,
  loading: () => <div className="lock-skeleton" aria-hidden="true" />,
});

export default function HeroVisual() {
  return <HeroSectionAnimation />;
}
