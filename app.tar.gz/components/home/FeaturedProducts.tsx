import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import ProductCard from '@/components/products/ProductCard';
import Reveal from '@/components/ui/Reveal';
import type { Dictionary } from '@/lib/i18n';
import type { Locale, ProductSummary } from '@/lib/types';

export default function FeaturedProducts({
  locale,
  dict,
  products,
}: {
  locale: Locale;
  dict: Dictionary;
  products: ProductSummary[];
}) {
  return (
    <section className="section section--tint">
      <div className="container">
        <Reveal className="section__head section__head--row">
          <div style={{ maxWidth: 640 }}>
            <span className="eyebrow">{dict.featured.eyebrow}</span>
            <h2 className="title">{dict.featured.title}</h2>
            <p className="lead">{dict.featured.subtitle}</p>
          </div>
          <Link href={`/${locale}/serrures`} className="btn btn--outline">
            {dict.featured.cta}
            <ArrowRight className="flip-rtl" />
          </Link>
        </Reveal>
        <div className="product-grid">
          {products.map((p, i) => (
            <Reveal key={p.id} delay={(i % 3) * 0.08}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
