'use client';

import { useEffect, useRef, useState, type ChangeEvent, type DragEvent, type FormEvent } from 'react';
import { Camera, CircleCheck, Info } from 'lucide-react';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { cleanText } from '@/lib/sanitize';
import { whatsappUrl } from '@/lib/site';

const ACCEPTED = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'];
const MAX_SIZE = 10 * 1024 * 1024;

export default function DoorCheck({ compact = false }: { compact?: boolean }) {
  const { dict } = useLocale();
  const d = dict.doorCheck;
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const [error, setError] = useState('');
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [doorType, setDoorType] = useState(d.doorTypes[0]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const accept = (f: File | undefined) => {
    if (!f) return;
    if (!ACCEPTED.includes(f.type)) return setError(d.errorType);
    if (f.size > MAX_SIZE) return setError(d.errorSize);
    setError('');
    setFile(f);
  };

  const onChange = (e: ChangeEvent<HTMLInputElement>) => accept(e.target.files?.[0]);
  const onDrop = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    setDrag(false);
    accept(e.dataTransfer.files?.[0]);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const lines = [
      d.message,
      `${d.name} : ${cleanText(name, 60) || '-'}`,
      `${d.city} : ${cleanText(city, 60) || '-'}`,
      `${d.doorType} : ${cleanText(doorType, 60)}`,
    ];
    if (file) lines.push(`(${d.photoAttached})`);
    const text = lines.join('\n');

    // Sur mobile : partage natif avec la photo (WhatsApp proposé directement)
    if (file && typeof navigator !== 'undefined' && 'canShare' in navigator) {
      try {
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], text });
          return;
        }
      } catch {
        /* partage annulé ou indisponible : ouverture de WhatsApp */
      }
    }
    window.open(whatsappUrl(text), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="doorcheck" id="verifier">
      <div style={{ position: 'relative' }}>
        <span className="eyebrow">{d.eyebrow}</span>
        <h2 className="title">{d.title}</h2>
        <p className="lead">{d.subtitle}</p>
        {!compact && (
          <ol className="steps-list">
            {d.steps.map((s, i) => (
              <li key={s}>
                <b>{i + 1}</b>
                {s}
              </li>
            ))}
          </ol>
        )}
      </div>

      <form className="doorcheck__form" onSubmit={onSubmit} noValidate>
        <label
          className={`dropzone${drag ? ' is-drag' : ''}`}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={onDrop}
        >
          {preview ? (
            <span className="dropzone__preview">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={preview} alt={d.photoAttached} />
              <span className="badge badge--green dropzone__ok">
                <CircleCheck width={14} height={14} />
                {d.change}
              </span>
            </span>
          ) : (
            <>
              <Camera aria-hidden="true" />
              <strong>{d.photo}</strong>
              <small>{d.photoHint}</small>
            </>
          )}
          <input ref={inputRef} type="file" accept={ACCEPTED.join(',')} capture="environment" onChange={onChange} />
        </label>
        {error && <p className="form-error">{error}</p>}

        <div className="form-grid form-grid--2">
          <div className="field">
            <label htmlFor="dc-name">{d.name}</label>
            <input id="dc-name" className="input" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="dc-city">{d.city}</label>
            <input id="dc-city" className="input" value={city} maxLength={60} onChange={(e) => setCity(e.target.value)} />
          </div>
        </div>
        <div className="field">
          <label htmlFor="dc-type">{d.doorType}</label>
          <select id="dc-type" className="select" value={doorType} onChange={(e) => setDoorType(e.target.value)}>
            {d.doorTypes.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </div>
        <button type="submit" className="btn btn--wa btn--block">
          <WhatsAppIcon />
          {d.submit}
        </button>
        <p className="note">
          <Info aria-hidden="true" />
          {d.note}
        </p>
      </form>
    </div>
  );
}
