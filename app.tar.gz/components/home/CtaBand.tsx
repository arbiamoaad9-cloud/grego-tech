import { WhatsAppIcon } from '@/components/ui/Icons';
import Reveal from '@/components/ui/Reveal';
import type { Dictionary } from '@/lib/i18n';
import { whatsappUrl } from '@/lib/site';

export default function CtaBand({ dict }: { dict: Dictionary }) {
  return (
    <section className="section" style={{ paddingTop: 0 }}>
      <div className="container">
        <Reveal className="cta-band">
          <div>
            <h2>{dict.cta.title}</h2>
            <p>{dict.cta.subtitle}</p>
          </div>
          <a
            className="btn btn--wa"
            href={whatsappUrl(dict.cart.waIntro.replace(/:$/, '.'))}
            target="_blank"
            rel="noopener noreferrer"
          >
            <WhatsAppIcon />
            {dict.cta.button}
          </a>
        </Reveal>
      </div>
    </section>
  );
}
