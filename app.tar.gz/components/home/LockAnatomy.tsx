'use client';

import dynamic from 'next/dynamic';

const LockAnatomy3D = dynamic(() => import('./LockAnatomy3D'), {
  ssr: false,
  loading: () => <section className="anatomy" aria-hidden="true" />,
});

export default function LockAnatomy() {
  return <LockAnatomy3D />;
}
