import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import HeroVisual from './HeroVisual';
import { WhatsAppIcon } from '@/components/ui/Icons';
import type { Dictionary } from '@/lib/i18n';
import type { Locale } from '@/lib/types';
import { whatsappUrl } from '@/lib/site';

export default function Hero({ locale, dict }: { locale: Locale; dict: Dictionary }) {
  const h = dict.hero;
  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="container hero__grid">
        <div className="hero__content">
          <span className="hero__badge">
            <span className="hero__badge-dot">
              <Sparkles aria-hidden="true" />
            </span>
            {h.badge}
          </span>
          <h1 id="hero-title" className="hero__title">
            {h.title} <span className="gradient-text">{h.titleHighlight}</span>
          </h1>
          <p className="hero__subtitle">{h.subtitle}</p>
          <div className="hero__ctas">
            <Link href={`/${locale}/serrures`} className="btn btn--primary">
              {h.ctaLocks}
              <ArrowRight className="flip-rtl" />
            </Link>
            <a
              href={whatsappUrl(dict.cart.waIntro.replace(/:$/, '.'))}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn--wa"
            >
              <WhatsAppIcon />
              {h.ctaWhatsapp}
            </a>
          </div>
          <dl className="hero__stats">
            {h.stats.map((s) => (
              <div className="hero__stat" key={s.label}>
                <dt className="sr-only">{s.label}</dt>
                <dd style={{ margin: 0 }}>
                  <strong dir="auto">{s.value}</strong>
                  <span>{s.label}</span>
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="hero__visual">
          <HeroVisual />
        </div>
      </div>
    </section>
  );
}
