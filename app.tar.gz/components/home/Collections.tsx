import Link from 'next/link';
import { ArrowRight, Building2, Droplets, Hand, ScanFace, type LucideIcon } from 'lucide-react';
import Reveal from '@/components/ui/Reveal';
import SmartImage from '@/components/ui/SmartImage';
import type { Dictionary } from '@/lib/i18n';
import type { Collection, Locale } from '@/lib/types';

const ICONS: Record<Collection, LucideIcon> = {
  'face-3d': ScanFace,
  handle: Hand,
  apartment: Building2,
  waterproof: Droplets,
};

export default function Collections({
  locale,
  dict,
  covers,
}: {
  locale: Locale;
  dict: Dictionary;
  covers: Partial<Record<Collection, string>>;
}) {
  const order: Collection[] = ['face-3d', 'handle', 'apartment', 'waterproof'];
  return (
    <section className="section" id="collections">
      <div className="container">
        <Reveal className="section__head">
          <span className="eyebrow">{dict.collections.eyebrow}</span>
          <h2 className="title">{dict.collections.title}</h2>
          <p className="lead">{dict.collections.subtitle}</p>
        </Reveal>
        <div className="collections">
          {order.map((key, i) => {
            const Icon = ICONS[key];
            const item = dict.collections.items[key];
            return (
              <Reveal key={key} delay={i * 0.08}>
                <Link href={`/${locale}/serrures?collection=${key}`} className="collection-card">
                  <div className="collection-card__media">
                    {covers[key] && <SmartImage src={covers[key]!} alt="" fill sizes="(max-width: 640px) 100vw, (max-width: 1100px) 50vw, 25vw" />}
                  </div>
                  <span className="collection-card__icon">
                    <Icon aria-hidden="true" />
                  </span>
                  <div className="collection-card__body">
                    <h3>{item.title}</h3>
                    <p>{item.desc}</p>
                    <span className="collection-card__cta">
                      {dict.collections.cta}
                      <ArrowRight className="flip-rtl" aria-hidden="true" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
