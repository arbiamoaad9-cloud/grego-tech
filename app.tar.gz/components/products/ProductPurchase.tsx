'use client';

import { useState } from 'react';
import { Minus, Plus, ShoppingBag } from 'lucide-react';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useCart } from '@/components/cart/CartProvider';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { formatPrice } from '@/lib/format';
import type { ProductSummary } from '@/lib/types';

export default function ProductPurchase({ product }: { product: ProductSummary }) {
  const { locale, dict } = useLocale();
  const { add, open } = useCart();
  const [variantId, setVariantId] = useState(product.variants[0]?.id ?? null);
  const [qty, setQty] = useState(1);

  const variant = product.variants.find((v) => v.id === variantId) ?? null;
  const unit = variant?.price ?? product.price;

  const addToCart = () => {
    add(
      {
        id: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0] ?? null,
        price: unit,
        variant: variant ? { id: variant.id, label: variant.label } : null,
      },
      qty,
      dict.product.added,
    );
    open();
  };

  return (
    <div style={{ display: 'grid', gap: 18 }}>
      {product.variants.length > 0 && (
        <div>
          <p className="label" style={{ marginBottom: 10 }}>
            {dict.product.variant}
          </p>
          <div className="variant-list" role="radiogroup" aria-label={dict.product.variant}>
            {product.variants.map((v) => (
              <button
                key={v.id}
                type="button"
                role="radio"
                aria-checked={v.id === variantId}
                className={`chip${v.id === variantId ? ' is-active' : ''}`}
                onClick={() => setVariantId(v.id)}
              >
                {v.label[locale]}
                {v.price !== null && v.price !== product.price && ` · ${formatPrice(v.price, locale)}`}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="pdp__buy">
        <div className="qty" aria-label={dict.product.quantity}>
          <button type="button" onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="-">
            <Minus />
          </button>
          <span aria-live="polite">{qty}</span>
          <button type="button" onClick={() => setQty((q) => Math.min(20, q + 1))} aria-label="+">
            <Plus />
          </button>
        </div>
        <button type="button" className="btn btn--dark" onClick={addToCart}>
          <ShoppingBag />
          {dict.product.addToCart}
        </button>
      </div>
      <button type="button" className="btn btn--wa btn--block" onClick={addToCart}>
        <WhatsAppIcon />
        {dict.product.orderWhatsapp}
      </button>
    </div>
  );
}
