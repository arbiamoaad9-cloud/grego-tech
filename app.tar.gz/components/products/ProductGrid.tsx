'use client';

import { useCallback, useMemo, useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { AnimatePresence, motion } from 'framer-motion';
import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react';
import ProductCard from './ProductCard';
import { MODE_ICONS } from '@/components/ui/Icons';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { discountPercent } from '@/lib/format';
import { t } from '@/lib/i18n';
import { cleanText, pickAllowed } from '@/lib/sanitize';
import { COLLECTIONS, FILTER_MODES, type Collection, type ProductSummary, type UnlockMode } from '@/lib/types';

const SORTS = ['featured', 'priceAsc', 'priceDesc', 'discount'] as const;
type Sort = (typeof SORTS)[number];

export default function ProductGrid({ products }: { products: ProductSummary[] }) {
  const { dict } = useLocale();
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const c = dict.catalog;

  // Lecture des paramètres d'URL en liste blanche (aucune valeur libre injectée)
  const [modes, setModes] = useState<UnlockMode[]>(() =>
    pickAllowed((params?.get('modes') || '').split(','), FILTER_MODES),
  );
  const [collection, setCollection] = useState<Collection | null>(
    () => pickAllowed([params?.get('collection') || ''], COLLECTIONS)[0] ?? null,
  );
  const [sort, setSort] = useState<Sort>(() => pickAllowed([params?.get('sort') || ''], SORTS)[0] ?? 'featured');
  const [query, setQuery] = useState(() => cleanText(params?.get('q') || '', 60));
  const [showFilters, setShowFilters] = useState(false);

  const syncUrl = useCallback(
    (next: { modes?: UnlockMode[]; collection?: Collection | null; sort?: Sort; q?: string }) => {
      const sp = new URLSearchParams();
      const m = next.modes ?? modes;
      const col = next.collection !== undefined ? next.collection : collection;
      const s = next.sort ?? sort;
      const q = next.q !== undefined ? next.q : query;
      if (m.length) sp.set('modes', m.join(','));
      if (col) sp.set('collection', col);
      if (s !== 'featured') sp.set('sort', s);
      if (q) sp.set('q', q);
      const qs = sp.toString();
      router.replace(`${pathname}${qs ? `?${qs}` : ''}`, { scroll: false });
    },
    [modes, collection, sort, query, pathname, router],
  );

  const toggleMode = (m: UnlockMode) => {
    const next = modes.includes(m) ? modes.filter((x) => x !== m) : [...modes, m];
    setModes(next);
    syncUrl({ modes: next });
  };

  const pickCollection = (col: Collection | null) => {
    setCollection(col);
    syncUrl({ collection: col });
  };

  const reset = () => {
    setModes([]);
    setCollection(null);
    setSort('featured');
    setQuery('');
    router.replace(pathname || '', { scroll: false });
  };

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = products.filter((p) => {
      if (collection && !p.collections.includes(collection)) return false;
      if (modes.length && !modes.every((m) => p.modes.includes(m))) return false;
      if (q && !`${p.name.fr} ${p.name.ar} ${p.sku}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const sorted = [...list];
    if (sort === 'priceAsc') sorted.sort((a, b) => a.price - b.price);
    else if (sort === 'priceDesc') sorted.sort((a, b) => b.price - a.price);
    else if (sort === 'discount')
      sorted.sort(
        (a, b) => (discountPercent(b.price, b.compareAtPrice) ?? 0) - (discountPercent(a.price, a.compareAtPrice) ?? 0),
      );
    else sorted.sort((a, b) => Number(b.featured) - Number(a.featured));
    return sorted;
  }, [products, collection, modes, query, sort]);

  const hasFilters = modes.length > 0 || collection !== null || query !== '' || sort !== 'featured';

  return (
    <div className="catalog">
      <aside className={`filters${showFilters ? ' is-open' : ''}`} aria-label={c.filters}>
        <div>
          <p className="filters__title">{c.modesLabel}</p>
          <div className="filters__chips">
            {FILTER_MODES.map((m) => {
              const Icon = MODE_ICONS[m];
              const active = modes.includes(m);
              return (
                <button
                  key={m}
                  type="button"
                  className={`chip${active ? ' is-active' : ''}`}
                  aria-pressed={active}
                  onClick={() => toggleMode(m)}
                >
                  <Icon aria-hidden="true" />
                  {dict.modes[m]}
                </button>
              );
            })}
          </div>
        </div>
        <div>
          <p className="filters__title">{c.collectionLabel}</p>
          <div className="filters__chips">
            <button
              type="button"
              className={`chip${collection === null ? ' is-active' : ''}`}
              aria-pressed={collection === null}
              onClick={() => pickCollection(null)}
            >
              {c.all}
            </button>
            {COLLECTIONS.map((col) => (
              <button
                key={col}
                type="button"
                className={`chip${collection === col ? ' is-active' : ''}`}
                aria-pressed={collection === col}
                onClick={() => pickCollection(col)}
              >
                {dict.collections.items[col].title}
              </button>
            ))}
          </div>
        </div>
        {hasFilters && (
          <button type="button" className="btn btn--outline btn--sm" onClick={reset}>
            <RotateCcw />
            {c.reset}
          </button>
        )}
      </aside>

      <div>
        <div className="catalog__toolbar">
          <button
            type="button"
            className="btn btn--outline btn--sm filters-toggle"
            onClick={() => setShowFilters((v) => !v)}
            aria-expanded={showFilters}
          >
            <SlidersHorizontal />
            {c.filters}
            {modes.length + (collection ? 1 : 0) > 0 && ` (${modes.length + (collection ? 1 : 0)})`}
          </button>
          <label className="search">
            <span className="sr-only">{c.search}</span>
            <Search aria-hidden="true" />
            <input
              className="input"
              type="search"
              value={query}
              maxLength={60}
              placeholder={c.search}
              onChange={(e) => {
                const v = cleanText(e.target.value, 60);
                setQuery(v);
                syncUrl({ q: v });
              }}
            />
          </label>
          <label>
            <span className="sr-only">{c.sortLabel}</span>
            <select
              className="select"
              value={sort}
              onChange={(e) => {
                const s = pickAllowed([e.target.value], SORTS)[0] ?? 'featured';
                setSort(s);
                syncUrl({ sort: s });
              }}
            >
              {SORTS.map((s) => (
                <option key={s} value={s}>
                  {c.sort[s]}
                </option>
              ))}
            </select>
          </label>
          <span className="catalog__count" aria-live="polite">
            {t(c.results, { count: results.length })}
          </span>
        </div>

        {results.length === 0 ? (
          <div className="catalog__empty">
            <p>{c.empty}</p>
            <button type="button" className="btn btn--primary btn--sm" onClick={reset}>
              {c.reset}
            </button>
          </div>
        ) : (
          <motion.div layout className="product-grid">
            <AnimatePresence mode="popLayout">
              {results.map((p, i) => (
                <motion.div
                  key={p.id}
                  layout
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.3 }}
                >
                  <ProductCard product={p} priority={i < 3} />
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </div>
    </div>
  );
}
