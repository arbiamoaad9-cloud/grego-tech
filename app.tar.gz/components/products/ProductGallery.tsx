'use client';

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import SmartImage from '@/components/ui/SmartImage';
import { useLocale } from '@/components/i18n/LocaleProvider';

export default function ProductGallery({ images, name, badge }: { images: string[]; name: string; badge?: string | null }) {
  const { dict } = useLocale();
  const [i, setI] = useState(0);
  const count = images.length;
  const go = (d: number) => setI((v) => (v + d + count) % count);

  return (
    <div className="gallery">
      <div className="gallery__main">
        {badge && (
          <span className="badge badge--sale" style={{ position: 'absolute', top: 18, insetInlineStart: 18, zIndex: 2 }}>
            {badge}
          </span>
        )}
        <AnimatePresence mode="wait">
          <motion.div
            key={i}
            style={{ position: 'absolute', inset: 0 }}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {images[i] && (
              <SmartImage src={images[i]} alt={`${name} — ${i + 1}/${count}`} fill priority={i === 0} sizes="(max-width: 960px) 100vw, 640px" />
            )}
          </motion.div>
        </AnimatePresence>
        {count > 1 && (
          <>
            <button type="button" className="icon-btn gallery__nav gallery__nav--prev" onClick={() => go(-1)} aria-label={dict.common.previous}>
              <ChevronLeft className="flip-rtl" />
            </button>
            <button type="button" className="icon-btn gallery__nav gallery__nav--next" onClick={() => go(1)} aria-label={dict.common.next}>
              <ChevronRight className="flip-rtl" />
            </button>
          </>
        )}
      </div>
      {count > 1 && (
        <div className="gallery__thumbs">
          {images.map((src, idx) => (
            <button
              key={src}
              type="button"
              className={`gallery__thumb${idx === i ? ' is-active' : ''}`}
              onClick={() => setI(idx)}
              aria-label={`${name} ${idx + 1}`}
              aria-current={idx === i}
            >
              <SmartImage src={src} alt="" fill sizes="78px" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
