'use client';

import Link from 'next/link';
import dynamic from 'next/dynamic';
import { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Eye, ShoppingBag } from 'lucide-react';
import ModeList from './ModeList';
import SmartImage from '@/components/ui/SmartImage';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useCart } from '@/components/cart/CartProvider';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { discountPercent, formatPrice } from '@/lib/format';
import type { ProductSummary } from '@/lib/types';

const QuickView = dynamic(() => import('./QuickView'), { ssr: false });

export default function ProductCard({ product, priority = false }: { product: ProductSummary; priority?: boolean }) {
  const { locale, dict } = useLocale();
  const { add, open } = useCart();
  const [quick, setQuick] = useState(false);

  const name = product.name[locale];
  const href = `/${locale}/serrures/${product.slug}`;
  const off = discountPercent(product.price, product.compareAtPrice);
  const priceLabel = formatPrice(product.price, locale);

  const addToCart = () =>
    add(
      {
        id: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0] ?? null,
        price: product.variants[0]?.price ?? product.price,
        variant: product.variants[0] ? { id: product.variants[0].id, label: product.variants[0].label } : null,
      },
      1,
      dict.product.added,
    );

  return (
    <article className="pcard">
      <div className="pcard__badges">
        {off && <span className="badge badge--sale">-{off}%</span>}
        {product.collections.includes('waterproof') && <span className="badge badge--soft">IP65</span>}
      </div>
      <button type="button" className="pcard__quick" onClick={() => setQuick(true)} aria-label={`${dict.product.quickView} — ${name}`}>
        <Eye />
      </button>

      <Link href={href} className="pcard__media" aria-label={name}>
        {product.images[0] && (
          <SmartImage
            src={product.images[0]}
            alt={name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1100px) 33vw, 300px"
            priority={priority}
            loading={priority ? undefined : 'lazy'}
          />
        )}
      </Link>

      <div className="pcard__body">
        <ModeList modes={product.modes} labels={dict.modes} max={5} />
        <h3 className="pcard__title">
          <Link href={href}>{name}</Link>
        </h3>
        <p className="pcard__desc">{product.shortDescription[locale]}</p>
        <div className="price">
          <span className="price__now">{priceLabel}</span>
          {product.compareAtPrice && <span className="price__old">{formatPrice(product.compareAtPrice, locale)}</span>}
        </div>
        <div className="pcard__actions">
          <button
            type="button"
            className="btn btn--wa"
            onClick={() => {
              addToCart();
              open();
            }}
          >
            <WhatsAppIcon />
            <span>{dict.product.orderShort}</span>
          </button>
          <button type="button" className="icon-btn" onClick={addToCart} aria-label={dict.product.addToCart} title={dict.product.addToCart}>
            <ShoppingBag />
          </button>
        </div>
      </div>

      <AnimatePresence>{quick && <QuickView product={product} onClose={() => setQuick(false)} />}</AnimatePresence>
    </article>
  );
}
