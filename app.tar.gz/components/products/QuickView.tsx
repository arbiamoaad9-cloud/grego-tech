'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { motion } from 'framer-motion';
import { ArrowRight, CircleCheck, ShoppingBag, X } from 'lucide-react';
import ModeList from './ModeList';
import SmartImage from '@/components/ui/SmartImage';
import { WhatsAppIcon } from '@/components/ui/Icons';
import { useCart } from '@/components/cart/CartProvider';
import { useLocale } from '@/components/i18n/LocaleProvider';
import { discountPercent, formatPrice } from '@/lib/format';
import type { ProductSummary } from '@/lib/types';

export default function QuickView({ product, onClose }: { product: ProductSummary; onClose: () => void }) {
  const { locale, dict } = useLocale();
  const { add, open } = useCart();
  const [img, setImg] = useState(0);
  const name = product.name[locale];
  const off = discountPercent(product.price, product.compareAtPrice);
  const priceLabel = formatPrice(product.price, locale);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  const addToCart = () => {
    const v = product.variants[0];
    add(
      {
        id: product.id,
        slug: product.slug,
        name: product.name,
        image: product.images[0] ?? null,
        price: v?.price ?? product.price,
        variant: v ? { id: v.id, label: v.label } : null,
      },
      1,
      dict.product.added,
    );
    onClose();
  };

  return createPortal(
    <motion.div
      className="backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={name}
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.98 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
      >
        <button type="button" className="icon-btn modal__close" onClick={onClose} aria-label={dict.common.close} autoFocus>
          <X />
        </button>
        <div className="qv">
          <div>
            <div className="qv__media">
              {product.images[img] && <SmartImage src={product.images[img]} alt={name} fill sizes="(max-width: 960px) 100vw, 470px" />}
            </div>
            {product.images.length > 1 && (
              <div className="gallery__thumbs" style={{ padding: 14 }}>
                {product.images.slice(0, 6).map((src, i) => (
                  <button
                    key={src}
                    type="button"
                    className={`gallery__thumb${i === img ? ' is-active' : ''}`}
                    onClick={() => setImg(i)}
                    aria-label={`${name} ${i + 1}`}
                  >
                    <SmartImage src={src} alt="" fill sizes="78px" />
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="qv__body">
            {off && <span className="badge badge--sale" style={{ justifySelf: 'start' }}>-{off}%</span>}
            <h2>{name}</h2>
            <div className="price">
              <span className="price__now">{priceLabel}</span>
              {product.compareAtPrice && <span className="price__old">{formatPrice(product.compareAtPrice, locale)}</span>}
            </div>
            <p style={{ color: 'var(--muted)' }}>{product.shortDescription[locale]}</p>
            <ModeList modes={product.modes} labels={dict.modes} labeled />
            {product.features[locale].length > 0 && (
              <ul className="feature-list">
                {product.features[locale].slice(0, 6).map((f) => (
                  <li key={f}>
                    <CircleCheck aria-hidden="true" />
                    {f}
                  </li>
                ))}
              </ul>
            )}
            <div style={{ display: 'grid', gap: 10 }}>
              <button type="button" className="btn btn--dark btn--block" onClick={addToCart}>
                <ShoppingBag />
                {dict.product.addToCart}
              </button>
              <button
                type="button"
                className="btn btn--wa btn--block"
                onClick={() => {
                  addToCart();
                  open();
                }}
              >
                <WhatsAppIcon />
                {dict.product.orderWhatsapp}
              </button>
              <Link href={`/${locale}/serrures/${product.slug}`} className="btn btn--ghost btn--block btn--sm" onClick={onClose}>
                {dict.product.viewDetails}
                <ArrowRight className="flip-rtl" />
              </Link>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>,
    document.body,
  );
}
