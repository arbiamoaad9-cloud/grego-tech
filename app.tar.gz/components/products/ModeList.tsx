import { MODE_ICONS } from '@/components/ui/Icons';
import type { Dictionary } from '@/lib/i18n';
import type { UnlockMode } from '@/lib/types';

export default function ModeList({
  modes,
  labels,
  labeled = false,
  max,
}: {
  modes: UnlockMode[];
  labels: Dictionary['modes'];
  labeled?: boolean;
  max?: number;
}) {
  const shown = max ? modes.slice(0, max) : modes;
  return (
    <ul className="modes" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
      {shown.map((m) => {
        const Icon = MODE_ICONS[m];
        return (
          <li key={m} className={`mode${labeled ? ' mode--labeled' : ''}`} title={labels[m]}>
            <Icon aria-hidden="true" />
            {labeled ? labels[m] : <span className="sr-only">{labels[m]}</span>}
          </li>
        );
      })}
      {max && modes.length > max && (
        <li className="mode" title={modes.slice(max).map((m) => labels[m]).join(', ')}>
          <small style={{ fontWeight: 800, fontSize: 12 }}>+{modes.length - max}</small>
        </li>
      )}
    </ul>
  );
}
