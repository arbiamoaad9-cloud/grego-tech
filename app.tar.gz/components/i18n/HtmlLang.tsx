'use client';

import { useEffect } from 'react';
import type { Locale } from '@/lib/types';

/** Synchronise <html lang/dir> lors des navigations côté client entre FR et AR. */
export default function HtmlLang({ locale }: { locale: Locale }) {
  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
  }, [locale]);
  return null;
}
