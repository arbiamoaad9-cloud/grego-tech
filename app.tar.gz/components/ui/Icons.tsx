import {
  CreditCard,
  Fingerprint,
  Hand,
  KeyRound,
  ScanFace,
  Smartphone,
  SquareAsterisk,
  type LucideIcon,
} from 'lucide-react';
import type { UnlockMode } from '@/lib/types';

export const MODE_ICONS: Record<UnlockMode, LucideIcon> = {
  fingerprint: Fingerprint,
  face: ScanFace,
  palm: Hand,
  code: SquareAsterisk,
  card: CreditCard,
  app: Smartphone,
  key: KeyRound,
};

export function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.87 9.87 0 0 0 4.74 1.21h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.15h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.38c0-4.54 3.7-8.23 8.25-8.23 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.82c0 4.54-3.7 8.23-8.23 8.23Zm4.52-6.16c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.13-.15.17-.25.25-.42.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.24 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.14-1.18-.06-.1-.22-.16-.47-.29Z" />
    </svg>
  );
}

/** Emblème Grego Tech : bouclier + trou de serrure. */
export function GregoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="gm-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0B63F6" />
          <stop offset="1" stopColor="#11C5E6" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="13" fill="url(#gm-g)" />
      <path
        d="M24 9.5 13 13.6v9.1c0 7.3 4.7 12.6 11 15.3 6.3-2.7 11-8 11-15.3v-9.1L24 9.5Z"
        fill="none"
        stroke="#fff"
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <circle cx="24" cy="21.5" r="3.6" fill="#fff" />
      <path d="M22.4 23.5h3.2l1 6.6h-5.2l1-6.6Z" fill="#fff" />
    </svg>
  );
}
