'use client';

import Image, { type ImageProps } from 'next/image';
import { useState } from 'react';
import { LockKeyhole } from 'lucide-react';

/** next/image avec repli élégant si l'image distante est indisponible. */
export default function SmartImage(props: ImageProps) {
  const [failed, setFailed] = useState(false);
  if (failed || !props.src) {
    return (
      <span className="img-fallback" aria-hidden="true">
        <LockKeyhole />
      </span>
    );
  }
  // eslint-disable-next-line jsx-a11y/alt-text
  return <Image {...props} onError={() => setFailed(true)} />;
}
